#!/bin/bash
# Instala ou atualiza o Pokan Tools (painel do Premiere) neste Mac.
# Pode rodar de novo quando quiser: o que já está instalado é aproveitado.
set -e

HERE="$(cd "$(dirname "$0")" && pwd)"
TOOLS="${POKAN_TOOLS_DIR:-$HOME/Library/Application Support/PokanTools}"
EXT="${POKAN_EXT_DIR:-$HOME/Library/Application Support/Adobe/CEP/extensions/com.pokan.tools}"
ARCH="$(uname -m)"

PY_TAG="20261110"
PY_VER="3.11.18"
if [ "$ARCH" = "arm64" ]; then
  PY_ARCH="aarch64"; PY_SHA="73f1ed14486aa278d331e95f7d6d452f5cfb69d90b418e26e62fd4846d53557d"; DENO_ARCH="aarch64"
else
  PY_ARCH="x86_64"; PY_SHA="9ff3ea8df9037e692939a3f2348f5fd760239ab8eb9d0d2d11d099457dda63a0"; DENO_ARCH="x86_64"
fi
PY_URL="https://github.com/astral-sh/python-build-standalone/releases/download/$PY_TAG/cpython-$PY_VER+$PY_TAG-$PY_ARCH-apple-darwin-install_only.tar.gz"
MODELS_URL="https://huggingface.co/AEmotionStudio/htdemucs-models/resolve/main"

step() { printf "\n▸ %s\n" "$1"; }
fail() { printf "\n✗ %s\n\nMande um print desta janela para o Luis.\n" "$1"; exit 1; }
sha() { shasum -a 256 "$1" | cut -d' ' -f1; }

# fetch <url> <destino> [sha256]: baixa para um arquivo temporário e só troca se a conferência bater
fetch() {
  curl -fL --retry 3 --progress-bar -o "$2.part" "$1" || { rm -f "$2.part"; return 1; }
  if [ -n "$3" ] && [ "$(sha "$2.part")" != "$3" ]; then rm -f "$2.part"; echo "conferência do arquivo falhou: $(basename "$2")"; return 1; fi
  mv "$2.part" "$2"
}

echo "Pokan Tools — instalador ($ARCH)"
[ -d "$HERE/arquivos/extensao" ] || fail "Não achei a pasta 'arquivos' ao lado deste instalador. Descompacte o zip inteiro antes."
mkdir -p "$TOOLS/bin" "$TOOLS/models"

if [ "$ARCH" = "arm64" ] && ! arch -x86_64 /usr/bin/true 2>/dev/null; then
  step "Instalando o Rosetta (o conversor de vídeo precisa dele)"
  softwareupdate --install-rosetta --agree-to-license || fail "Não consegui instalar o Rosetta."
fi

# o pacote de atualização (baixado pelo botão do painel) vem sem o conversor: usa o que já está instalado
if [ -f "$HERE/arquivos/ffmpeg" ]; then
  step "Copiando o conversor de vídeo"
  cp "$HERE/arquivos/ffmpeg" "$HERE/arquivos/ffprobe" "$TOOLS/bin/"
  chmod +x "$TOOLS/bin/ffmpeg" "$TOOLS/bin/ffprobe"
elif [ ! -x "$TOOLS/bin/ffmpeg" ]; then
  fail "Este pacote é só de atualização. Use o instalador completo (zip) na primeira vez."
fi

step "Baixando o baixador de vídeos (sempre a versão mais nova)"
if fetch "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos" "$TOOLS/bin/yt-dlp"; then chmod +x "$TOOLS/bin/yt-dlp"
elif [ ! -x "$TOOLS/bin/yt-dlp" ]; then fail "Não consegui baixar o yt-dlp. Confira a internet e rode de novo."; fi

if [ ! -x "$TOOLS/bin/deno" ]; then
  step "Baixando o apoio para links do YouTube"
  fetch "https://github.com/denoland/deno/releases/latest/download/deno-$DENO_ARCH-apple-darwin.zip" "$TOOLS/bin/deno.zip" || fail "Não consegui baixar o deno."
  unzip -oq "$TOOLS/bin/deno.zip" -d "$TOOLS/bin" && rm -f "$TOOLS/bin/deno.zip"
fi

PYCHECK="import demucs, faster_whisper, librosa, safetensors, soundfile, torch"
if ! "$TOOLS/venv/bin/python" -c "$PYCHECK" 2>/dev/null; then
  step "Instalando o motor de IA (legendas, separação, batidas). É a parte demorada: uns 5 a 15 minutos."
  fetch "$PY_URL" "$TOOLS/python.tar.gz" "$PY_SHA" || fail "Não consegui baixar o Python."
  rm -rf "$TOOLS/python" "$TOOLS/venv"
  tar -xzf "$TOOLS/python.tar.gz" -C "$TOOLS" && rm -f "$TOOLS/python.tar.gz"
  "$TOOLS/python/bin/python3" -m venv "$TOOLS/venv"
  "$TOOLS/venv/bin/python" -m pip install -q --upgrade pip
  # versões fixas que têm pacote pronto para Mac Intel e Apple Silicon. O demucs e duas
  # dependências dele só existem como código-fonte (Python puro), então entram num passo à parte;
  # o resto é obrigado a vir pronto, para nunca tentar compilar na máquina da pessoa.
  "$TOOLS/venv/bin/python" -m pip install -q --only-binary=:all: \
    "numpy==1.26.4" "torch==2.2.2" "torchaudio==2.2.2" "faster-whisper==1.2.1" "numba==0.60.0" "llvmlite==0.43.0" \
    "librosa==0.11.0" "soundfile==0.13.1" "safetensors==0.7.0" || fail "A instalação do motor de IA falhou."
  "$TOOLS/venv/bin/python" -m pip install -q "demucs==4.0.1" || fail "A instalação do separador de áudio falhou."
  "$TOOLS/venv/bin/python" -c "$PYCHECK" || fail "O motor de IA instalou mas não abriu."
fi

step "Conferindo os modelos de separação de áudio"
while read -r name want; do
  if [ ! -f "$TOOLS/models/$name" ] || [ "$(sha "$TOOLS/models/$name")" != "$want" ]; then
    echo "  baixando $name"
    fetch "$MODELS_URL/$name" "$TOOLS/models/$name" "$want" || fail "Não consegui baixar $name."
  fi
done <<'LIST'
htdemucs.safetensors 36dc503a9ca7dc902a7e90efd0bf80389d18d4414b13de785d0514a3825a7f17
htdemucs_config.json bd61d6bd414fbdd60248446f5e73afffe091d9cd53659cfe60271e11fe81470d
htdemucs_ft.safetensors a89307833d7c6f2f4b9ab0f686fde5b8d1e9551301cdcb982b61852c8c5a4d30
htdemucs_ft_config.json f58768589a46afcc4afc5cc3c082155fff014da8d3f588382b4f8414c5c45831
LIST

# Borrão de rostos e áreas: entra à parte para quem já tinha o motor de IA não precisar reinstalar tudo
if ! "$TOOLS/venv/bin/python" -c "import cv2; cv2.TrackerCSRT_create; cv2.FaceDetectorYN" 2>/dev/null; then
  step "Instalando o detector de rostos (borrão)"
  "$TOOLS/venv/bin/python" -m pip install -q --only-binary=:all: "opencv-contrib-python-headless==4.10.0.84" || fail "A instalação do detector de rostos falhou."
fi
YUNET="face_detection_yunet_2023mar.onnx"
YUNET_SHA="8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4"
if [ ! -f "$TOOLS/models/$YUNET" ] || [ "$(sha "$TOOLS/models/$YUNET")" != "$YUNET_SHA" ]; then
  echo "  baixando $YUNET"
  fetch "https://huggingface.co/opencv/face_detection_yunet/resolve/main/$YUNET" "$TOOLS/models/$YUNET" "$YUNET_SHA" || fail "Não consegui baixar o detector de rostos."
fi

step "Instalando o painel no Premiere"
rm -rf "$EXT"
mkdir -p "$EXT"
cp -R "$HERE/arquivos/extensao/." "$EXT/"

# arquivos recebidos pelo WhatsApp vêm marcados como "baixados da internet"; sem tirar a marca o macOS barra
xattr -dr com.apple.quarantine "$EXT" "$TOOLS/bin" 2>/dev/null || true

step "Testando"
"$TOOLS/bin/ffmpeg" -version >/dev/null 2>&1 || fail "O conversor de vídeo não abriu."
"$TOOLS/bin/yt-dlp" --version >/dev/null 2>&1 || fail "O baixador de vídeos não abriu."
"$TOOLS/venv/bin/python" -c "$PYCHECK" || fail "O motor de IA não abriu."

printf "\n✓ Pokan Tools instalado.\n\nFeche o Premiere (Cmd+Q), abra de novo e vá em Janela > Extensões > Pokan Tools.\n"
