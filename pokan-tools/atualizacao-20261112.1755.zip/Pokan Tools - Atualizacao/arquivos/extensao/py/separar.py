# Separa um WAV estéreo 44,1 kHz em trilhas. Uso:
#   separar.py <wav> <pasta_saida> <modelo.safetensors> <config.json> <2|4>
# Os pesos vêm em safetensors (só números, sem código embutido); a rede é montada aqui
# a partir do config. Modo 2: vocals + no_vocals (mix menos a voz). Modo 4: as quatro trilhas.
import json
import os
import sys
from fractions import Fraction

import soundfile as sf
import torch
from demucs.apply import apply_model
from demucs.htdemucs import HTDemucs
from safetensors.torch import load_file

wav_path, out_dir, weights, config, mode = sys.argv[1:6]

kwargs = json.load(open(config))["kwargs"]
model = HTDemucs(segment=Fraction(39, 5), **kwargs)  # 7,8 s: o trecho com que o modelo foi treinado
# a conversão guardou os pesos em meia precisão e com o prefixo "state."
state = {k[6:] if k.startswith("state.") else k: v.float() for k, v in load_file(weights).items()}
model.load_state_dict(state, strict=True)
model.eval()

audio, rate = sf.read(wav_path, dtype="float32", always_2d=True)
if rate != model.samplerate:
    sys.exit("O áudio precisa estar em %d Hz" % model.samplerate)
mix = torch.from_numpy(audio.T.copy())
if mix.shape[0] == 1:
    mix = mix.repeat(2, 1)

ref = mix.mean(0)
mean, std = ref.mean(), ref.std() + 1e-8
stems = apply_model(model, ((mix - mean) / std)[None], shifts=1, split=True, overlap=0.25, progress=True, device="cpu")[0]
stems = stems * std + mean

out = {name: stems[i] for i, name in enumerate(model.sources)}
if mode == "2":
    out = {"vocals": out["vocals"], "no_vocals": mix - out["vocals"]}

os.makedirs(out_dir, exist_ok=True)
for name, data in out.items():
    sf.write(os.path.join(out_dir, name + ".wav"), data.clamp(-1, 1).T.numpy(), rate, subtype="PCM_24")
print("OK " + ",".join(out), flush=True)
