# Gera um vídeo transparente (ProRes 4444) só com o borrão, para ficar por cima do clipe original. Uso:
#   borrar.py <ffmpeg> <video> <inicio> <duracao> <fps> <largura> <altura> <saida.mov> <rostos|area> <media|forte|mosaico> <modelo_yunet> [x y w h t0]
# largura/altura = tamanho do quadro como ele aparece (já girado). Em "area", x y w h vão de 0 a 1
# e t0 é o instante (segundos a partir de <inicio>) em que a área foi marcada.
# Imprime "PT <0-100>" durante o trabalho e, no fim, "OK <quadros com borrão> <segundo em que perdeu o alvo, ou -1>".
import os
import subprocess
import sys
import tempfile
from fractions import Fraction

import cv2
import numpy as np

ffmpeg, video, ss, dur, fps, W, H, out_path, mode, strength, model = sys.argv[1:12]
W, H, dur = int(W), int(H), float(dur)
rate = float(Fraction(fps))
total = max(1, int(round(dur * rate)))


def progress(done, lo, hi):
    print("PT %d" % (lo + (hi - lo) * min(1.0, done / total)), flush=True)


def frames(w, h):
    """Quadros do trecho, na taxa da sequência, já no tamanho pedido."""
    cmd = [ffmpeg, "-v", "error", "-ss", ss, "-t", str(dur), "-i", video, "-an",
           "-vf", "fps=%s,scale=%d:%d" % (fps, w, h), "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    size = w * h * 3
    while True:
        buf = proc.stdout.read(size)
        if len(buf) < size:
            break
        yield np.frombuffer(buf, np.uint8).reshape(h, w, 3)
    proc.stdout.close()
    proc.wait()


def small_size(limit):
    k = min(1.0, limit / max(W, H))
    return max(2, int(W * k) // 2 * 2), max(2, int(H * k) // 2 * 2)


# ---------- 1ª passada: onde está o que esconder (caixas de 0 a 1 por quadro) ----------

def find_faces():
    sw, sh = small_size(640)
    det = cv2.FaceDetectorYN.create(model, "", (sw, sh), 0.5, 0.3, 100)
    tracks = []  # cada rosto seguido: {quadro: caixa}
    n = 0
    for i, img in enumerate(frames(sw, sh)):
        n = i + 1
        _, found = det.detect(img)
        for f in (found if found is not None else []):
            box = np.array([f[0] / sw, f[1] / sh, f[2] / sw, f[3] / sh], np.float32)
            cx, cy = box[0] + box[2] / 2, box[1] + box[3] / 2
            best, best_d = None, 1e9
            for t in tracks:
                last_i = t["last"]
                if last_i == i or i - last_i > rate:  # já usado neste quadro, ou sumiu há mais de 1 s
                    continue
                b = t["boxes"][last_i]
                d = abs(b[0] + b[2] / 2 - cx) + abs(b[1] + b[3] / 2 - cy)
                if d < best_d and d < 1.5 * max(b[2], b[3], box[2], box[3]):
                    best, best_d = t, d
            if best is None:
                best = {"boxes": {}, "last": i, "score": 0.0}
                tracks.append(best)
            best["score"] = max(best["score"], float(f[-1]))
            best["boxes"][i] = box
            best["last"] = i
        if i % 10 == 0:
            progress(i, 0, 40)
    per_frame = [[] for _ in range(n)]
    pad = int(rate * 0.3)
    for t in tracks:
        idx = sorted(t["boxes"])
        # engano típico (fumaça, estampa): aparece em um ou dois quadros, ou pisca o tempo todo
        # sem nunca chegar a uma certeza alta. Rosto de verdade é achado em quase todo quadro.
        steady = len(idx) / (idx[-1] - idx[0] + 1)
        if len(idx) < 3 or (t["score"] < 0.8 and steady < 0.6):
            continue
        full = {}
        for a, b in zip(idx, idx[1:]):  # preenche os quadros em que o detector piscou
            for k in range(a, b):
                u = (k - a) / (b - a)
                full[k] = t["boxes"][a] * (1 - u) + t["boxes"][b] * u
        full[idx[-1]] = t["boxes"][idx[-1]]
        for k in range(max(0, idx[0] - pad), idx[0]):  # começa um pouco antes e termina um pouco depois
            full[k] = t["boxes"][idx[0]]
        for k in range(idx[-1] + 1, min(n, idx[-1] + pad + 1)):
            full[k] = t["boxes"][idx[-1]]
        keys = sorted(full)
        arr = np.array([full[k] for k in keys])
        for j, k in enumerate(keys):  # suaviza o tremor do detector
            per_frame[k].append(arr[max(0, j - 2):j + 3].mean(axis=0))
    return per_frame, -1


def track_area(box, t0):
    sw, sh = small_size(480)
    if total * sw * sh * 3 > 6e9:
        sys.exit("Trecho longo demais para seguir uma área. Corte um pedaço menor (até %d s) e tente de novo." % int(6e9 / (sw * sh * 3) / rate))
    tmp = tempfile.NamedTemporaryFile(suffix=".raw", delete=False)
    tmp.close()
    store = np.memmap(tmp.name, np.uint8, "w+", shape=(total + 2, sh, sw, 3))
    n = 0
    for i, img in enumerate(frames(sw, sh)):
        if i >= total + 2:
            break
        store[i] = img
        n = i + 1
        if i % 10 == 0:
            progress(i, 0, 20)
    k0 = min(n - 1, max(0, int(round(float(t0) * rate))))
    start = (int(box[0] * sw), int(box[1] * sh), max(4, int(box[2] * sw)), max(4, int(box[3] * sh)))
    per_frame = [[] for _ in range(n)]
    per_frame[k0] = [np.array(box, np.float32)]
    lost_at = -1
    hold = int(rate * 0.35)
    done = 0
    for order in (range(k0 + 1, n), range(k0 - 1, -1, -1)):
        tracker = cv2.TrackerCSRT_create()
        tracker.init(np.ascontiguousarray(store[k0]), start)
        last, misses = np.array(box, np.float32), 0
        for k in order:
            ok, b = tracker.update(np.ascontiguousarray(store[k]))
            if ok:
                last, misses = np.array([b[0] / sw, b[1] / sh, b[2] / sw, b[3] / sh], np.float32), 0
            else:
                misses += 1
                if misses > hold:  # saiu de quadro ou foi encoberto: para de borrar
                    if lost_at < 0 or k / rate < lost_at:
                        lost_at = k / rate
                    break
            per_frame[k] = [last]
            done += 1
            if done % 10 == 0:
                progress(done, 20, 40)
    del store
    os.unlink(tmp.name)
    return per_frame, lost_at


# ---------- 2ª passada: desenha o borrão em tamanho cheio ----------

def blur(roi):
    h, w = roi.shape[:2]
    if strength == "mosaico":
        cells = 8  # quadrados no lado maior
        small = cv2.resize(roi, (max(1, round(w * cells / max(w, h))), max(1, round(h * cells / max(w, h)))), interpolation=cv2.INTER_AREA)
        return cv2.resize(small, (w, h), interpolation=cv2.INTER_NEAREST)
    sigma = max(w, h) * (0.3 if strength == "forte" else 0.14)
    d = max(1, int(sigma / 4))  # borra uma versão reduzida: mesmo resultado, muito mais rápido
    small = cv2.resize(roi, (max(1, w // d), max(1, h // d)), interpolation=cv2.INTER_AREA)
    small = cv2.GaussianBlur(small, (0, 0), max(0.8, sigma / d))
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_LINEAR)


def mask(w, h):
    m = np.zeros((h, w), np.uint8)
    edge = max(2, int(min(w, h) * 0.08))
    if mode == "rostos":
        cv2.ellipse(m, (w // 2, h // 2), (max(1, w // 2 - edge), max(1, h // 2 - edge)), 0, 0, 360, 255, -1)
    else:
        cv2.rectangle(m, (edge, edge), (w - edge - 1, h - edge - 1), 255, -1)
    return cv2.GaussianBlur(m, (0, 0), edge / 2.0)


boxes, lost = find_faces() if mode == "rostos" else track_area([float(v) for v in sys.argv[12:16]], sys.argv[16])
grow = 0.35 if mode == "rostos" else 0.12  # folga em volta da caixa

enc = subprocess.Popen([ffmpeg, "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", "%dx%d" % (W, H), "-r", fps, "-i", "-",
                        "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le", "-q:v", "20", out_path], stdin=subprocess.PIPE)
canvas = np.zeros((H, W, 4), np.uint8)
dirty = []
blurred = 0
for i, img in enumerate(frames(W, H)):
    for (x0, y0, x1, y1) in dirty:
        canvas[y0:y1, x0:x1] = 0
    dirty = []
    for b in (boxes[i] if i < len(boxes) else []):
        bw, bh = b[2] * W, b[3] * H
        x0, y0 = int(max(0, b[0] * W - bw * grow)), int(max(0, b[1] * H - bh * grow))
        x1, y1 = int(min(W, b[0] * W + bw * (1 + grow))), int(min(H, b[1] * H + bh * (1 + grow)))
        if x1 - x0 < 4 or y1 - y0 < 4:
            continue
        soft, m = blur(img[y0:y1, x0:x1]), mask(x1 - x0, y1 - y0)
        old_a = canvas[y0:y1, x0:x1, 3]
        if old_a.any():  # caixas que se cruzam: mistura pelo contorno suave, sem deixar um retângulo marcado
            wgt = (m.astype(np.float32) / 255)[:, :, None]
            mixed = soft * wgt + canvas[y0:y1, x0:x1, :3] * (1 - wgt)
            soft = np.where((old_a == 0)[:, :, None], soft, mixed).astype(np.uint8)
        canvas[y0:y1, x0:x1, :3] = soft
        canvas[y0:y1, x0:x1, 3] = np.maximum(old_a, m)
        dirty.append((x0, y0, x1, y1))
    if dirty:
        blurred += 1
    enc.stdin.write(canvas.tobytes())
    if i % 5 == 0:
        progress(i, 40, 100)
enc.stdin.close()
if enc.wait() != 0:
    sys.exit("O ffmpeg não conseguiu gravar o borrão.")
print("OK %d %.2f" % (blurred, lost), flush=True)
