# Detecta as batidas de um WAV. Uso: batidas.py <wav>
# Imprime uma linha "BEATS {json}" com bpm e os tempos em segundos.
import json
import sys

import librosa
import numpy as np

y, sr = librosa.load(sys.argv[1], sr=22050, mono=True)
tempo, beats = librosa.beat.beat_track(y=y, sr=sr, units="time")
bpm = float(np.atleast_1d(tempo)[0])
print("BEATS " + json.dumps({"bpm": round(bpm, 1), "beats": [round(float(b), 3) for b in beats]}), flush=True)
