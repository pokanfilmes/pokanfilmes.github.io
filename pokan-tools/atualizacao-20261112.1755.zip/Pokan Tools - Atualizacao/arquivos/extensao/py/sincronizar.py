# Acha o atraso entre gravações do mesmo momento, pelo som. Uso:
#   sincronizar.py <referencia.wav> <outro.wav> [<outro.wav> ...]
# Para cada "outro" imprime "LAG <i> <segundos> <confianca>": o mesmo som aparece
# <segundos> mais tarde no outro arquivo do que na referência (negativo = mais cedo).
import sys

import numpy as np
import soundfile as sf


def load(path):
    data, rate = sf.read(path, dtype="float32", always_2d=True)
    x = data.mean(axis=1)
    x -= x.mean()
    return x, rate


ref, rate = load(sys.argv[1])
for i, path in enumerate(sys.argv[2:]):
    other, _ = load(path)
    n = 1
    while n < len(ref) + len(other):
        n *= 2
    # correlação cruzada com pesos de fase (GCC-PHAT): aguenta microfones e volumes diferentes
    cross = np.fft.rfft(other, n) * np.conj(np.fft.rfft(ref, n))
    cross /= np.abs(cross) + 1e-9 * np.abs(cross).max() + 1e-20
    corr = np.fft.irfft(cross, n)
    peak = int(np.argmax(corr))
    lag = peak if peak < n // 2 else peak - n
    conf = float(corr[peak] / (np.std(corr) + 1e-12))
    print("LAG %d %.5f %.1f" % (i, lag / rate, conf), flush=True)
