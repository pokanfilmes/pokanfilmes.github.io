# Transcreve um WAV e escreve um SRT. Uso:
#   transcrever.py <wav> <srt> <modelo> <idioma|auto> <linha|palavras> <tamanho> [transcribe|translate] [palavras.json]
# "translate" escreve a legenda em inglês, qualquer que seja o idioma da fala.
# "linha": tamanho = máximo de caracteres por legenda; "palavras": tamanho = palavras por legenda.
# Com [palavras.json], grava também cada palavra com início e fim: [[inicio, fim, "palavra"], ...].
# Imprime "PT <0-100>" durante o trabalho e "OK <n legendas>" no fim.
import json
import sys

from faster_whisper import WhisperModel

wav, srt, model_name, lang, mode, size = sys.argv[1:7]
size = int(size)
task = sys.argv[7] if len(sys.argv) > 7 else "transcribe"

model = WhisperModel(model_name, device="cpu", compute_type="int8")
segments, info = model.transcribe(
    wav,
    language=None if lang == "auto" else lang,
    task=task,
    word_timestamps=True,
    vad_filter=True,
)

words = []
for seg in segments:
    for w in seg.words or []:
        text = w.word.strip()
        if text:
            words.append((w.start, w.end, text))
    if info.duration:
        print("PT %d" % min(99, int(seg.end / info.duration * 100)), flush=True)

if len(sys.argv) > 8:
    with open(sys.argv[8], "w", encoding="utf-8") as f:
        json.dump([[round(a, 3), round(b, 3), t] for a, b, t in words], f, ensure_ascii=False)

groups = []
cur = []
for i, (start, end, text) in enumerate(words):
    cur.append((start, end, text))
    nxt = words[i + 1] if i + 1 < len(words) else None
    if mode == "palavras":
        full = len(cur) >= size
    else:
        length = len(" ".join(t for _, _, t in cur))
        full = nxt is None or length + 1 + len(nxt[2]) > size
    pause = nxt is not None and nxt[0] - end > 0.6
    sentence_end = text[-1] in ".?!"
    if nxt is None or full or pause or sentence_end:
        groups.append(cur)
        cur = []


def stamp(t):
    ms = int(round(max(0.0, t) * 1000))
    return "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


with open(srt, "w", encoding="utf-8") as f:
    for i, g in enumerate(groups):
        start = g[0][0]
        end = max(g[-1][1], start + 0.12)
        if i + 1 < len(groups):
            end = min(end, groups[i + 1][0][0])  # nunca sobrepõe a próxima
        f.write("%d\n%s --> %s\n%s\n\n" % (i + 1, stamp(start), stamp(end), " ".join(t for _, _, t in g)))

print("OK %d" % len(groups), flush=True)
