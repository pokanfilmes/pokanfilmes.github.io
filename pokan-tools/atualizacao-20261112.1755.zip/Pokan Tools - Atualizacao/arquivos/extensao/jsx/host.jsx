// Pokan Tools — lado Premiere (ExtendScript, ES3: sem JSON nativo, sem let/const)

var FT_TICKS = 254016000000; // ticks do Premiere por segundo

function ft_q(s) {
  s = String(s);
  return '"' + s.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '') + '"';
}

function ft_ping() { return "ok"; }

function ft_projectDir() {
  if (app.project && app.project.path) {
    var f = new File(app.project.path);
    if (f.parent) return f.parent.fsName;
  }
  return "";
}

function ft_childBin(parent, name) {
  for (var i = 0; i < parent.children.numItems; i++) {
    var c = parent.children[i];
    if (c.type === ProjectItemType.BIN && c.name === name) return c;
  }
  return null;
}

// "Pokan Tools/SFX" -> cria a hierarquia de bins se faltar
function ft_getBin(binPath) {
  var parts = binPath.split("/");
  var cur = app.project.rootItem;
  for (var i = 0; i < parts.length; i++) {
    var b = ft_childBin(cur, parts[i]);
    if (!b) {
      cur.createBin(parts[i]);
      b = ft_childBin(cur, parts[i]);
    }
    cur = b;
  }
  return cur;
}

function ft_norm(p) { return String(p).replace(/\\/g, "/").toLowerCase(); }

function ft_findInBin(bin, mediaPath) {
  var target = ft_norm(mediaPath);
  for (var i = bin.children.numItems - 1; i >= 0; i--) {
    var c = bin.children[i];
    if (c.type !== ProjectItemType.BIN && ft_norm(c.getMediaPath()) === target) return c;
  }
  return null;
}

function ft_trackFree(track, start, end) {
  for (var j = 0; j < track.clips.numItems; j++) {
    var c = track.clips[j];
    if (c.start.seconds < end - 0.001 && c.end.seconds > start + 0.001) return false;
  }
  return true;
}

function ft_addAudioTrack(seq) {
  app.enableQE();
  var qs = qe.project.getActiveSequence();
  // addTracks(nVideo, depoisDoVideo, nAudio, tipoAudio(1=estéreo), depoisDoAudio, nSubmix, tipoSubmix, depoisDoSubmix)
  qs.addTracks(0, 0, 1, 1, seq.audioTracks.numTracks, 0, 0, 0);
}

function ft_addVideoAndAudioTrack(seq) {
  app.enableQE();
  var qs = qe.project.getActiveSequence();
  qs.addTracks(1, seq.videoTracks.numTracks, 1, 1, seq.audioTracks.numTracks, 0, 0, 0);
}

function ft_time(sec) { var t = new Time(); t.seconds = sec; return t; }

// Coloca em uma trilha de áudio livre a partir de `start` (cria trilha se precisar).
// `skip` = quantas trilhas livres pular (para empilhar stems lado a lado).
function ft_placeAudio(item, start, dur, skip) {
  var seq = app.project.activeSequence;
  if (!seq) return "ERR:sem sequência ativa";
  var found = -1, seen = 0;
  for (var i = 0; i < seq.audioTracks.numTracks; i++) {
    if (ft_trackFree(seq.audioTracks[i], start, start + dur)) {
      if (seen === skip) { found = i; break; }
      seen++;
    }
  }
  if (found < 0) {
    ft_addAudioTrack(seq);
    found = seq.audioTracks.numTracks - 1;
  }
  seq.audioTracks[found].overwriteClip(item, ft_time(start));
  return "OK:A" + (found + 1);
}

function ft_placeVideo(item, start, dur) {
  var seq = app.project.activeSequence;
  if (!seq) return "ERR:sem sequência ativa";
  var n = Math.min(seq.videoTracks.numTracks, seq.audioTracks.numTracks);
  var found = -1;
  for (var i = 0; i < n; i++) {
    if (ft_trackFree(seq.videoTracks[i], start, start + dur) && ft_trackFree(seq.audioTracks[i], start, start + dur)) { found = i; break; }
  }
  if (found < 0) {
    ft_addVideoAndAudioTrack(seq);
    found = seq.videoTracks.numTracks - 1;
  }
  seq.videoTracks[found].overwriteClip(item, ft_time(start));
  return "OK:V" + (found + 1);
}

// where: "none" | "playhead" | número em segundos
function ft_import(mediaPath, binPath, where, dur, kind, skip) {
  try {
    var bin = ft_getBin(binPath);
    var item = ft_findInBin(bin, mediaPath);
    if (!item) {
      app.project.importFiles([mediaPath], true, bin, false);
      item = ft_findInBin(bin, mediaPath);
    }
    if (!item) return "ERR:não consegui importar";
    if (where === "none") return "OK:bin";
    var seq = app.project.activeSequence;
    if (!seq) return "OK:bin (sem sequência aberta)";
    var start = where === "playhead" ? seq.getPlayerPosition().seconds : Number(where);
    return kind === "video" ? ft_placeVideo(item, start, dur) : ft_placeAudio(item, start, dur, skip || 0);
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// Clipe selecionado na timeline (prefere o de áudio)
function ft_selectedClip() {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return '{"err":"Abra uma sequência"}';
    var sel = seq.getSelection();
    if (!sel || sel.length === 0) return '{"err":"Selecione um clipe na timeline"}';
    var pick = null;
    for (var i = 0; i < sel.length; i++) {
      if (sel[i].mediaType === "Audio") { pick = sel[i]; break; }
    }
    if (!pick) pick = sel[0];
    if (!pick.projectItem) return '{"err":"Clipe sem mídia"}';
    var p = pick.projectItem.getMediaPath();
    if (!p) return '{"err":"Clipe sem arquivo (gráfico ou nest?)"}';
    return '{"path":' + ft_q(p) + ',"name":' + ft_q(pick.name) +
      ',"start":' + pick.start.seconds + ',"end":' + pick.end.seconds +
      ',"inPoint":' + pick.inPoint.seconds + ',"nodeId":' + ft_q(pick.nodeId) +
      ',"frame":' + (Number(seq.timebase) / FT_TICKS) + '}';
  } catch (e) {
    return '{"err":' + ft_q(e.toString()) + '}';
  }
}

// Desativa (silencia) os clipes de áudio com esse nodeId
function ft_disableClip(nodeId) {
  var seq = app.project.activeSequence;
  if (!seq) return "ERR";
  for (var i = 0; i < seq.audioTracks.numTracks; i++) {
    var t = seq.audioTracks[i];
    for (var j = 0; j < t.clips.numItems; j++) {
      if (t.clips[j].nodeId === nodeId) { t.clips[j].disabled = true; return "OK"; }
    }
  }
  return "ERR:não achei";
}

// ---------- Áudio: volume ----------

function ft_clipJson(c) {
  return '{"path":' + ft_q(c.projectItem.getMediaPath()) + ',"name":' + ft_q(c.name) +
    ',"start":' + c.start.seconds + ',"end":' + c.end.seconds +
    ',"inPoint":' + c.inPoint.seconds + ',"nodeId":' + ft_q(c.nodeId) + '}';
}

function ft_selectedAudioClips() {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return '{"err":"Abra uma sequência"}';
    var sel = seq.getSelection(), out = [];
    for (var i = 0; sel && i < sel.length; i++) {
      if (sel[i].mediaType === "Audio" && sel[i].projectItem && sel[i].projectItem.getMediaPath()) out.push(ft_clipJson(sel[i]));
    }
    if (!out.length) return '{"err":"Selecione um ou mais clipes de áudio na timeline"}';
    return '{"clips":[' + out.join(",") + ']}';
  } catch (e) {
    return '{"err":' + ft_q(e.toString()) + '}';
  }
}

function ft_seqInfo() {
  var seq = app.project.activeSequence;
  if (!seq) return '{"err":"Abra uma sequência"}';
  return '{"name":' + ft_q(seq.name) + ',"dur":' + (Number(seq.end) / FT_TICKS) + ',"frame":' + (Number(seq.timebase) / FT_TICKS) +
    ',"width":' + seq.frameSizeHorizontal + ',"height":' + seq.frameSizeVertical + '}';
}

// Exporta a sequência inteira direto para arquivo (trava o Premiere até terminar)
function ft_exportDirect(outPath, presetPath) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:sem sequência ativa";
    var r = seq.exportAsMediaDirect(outPath, presetPath, app.encoder.ENCODE_ENTIRE);
    return "OK:" + r;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// O "Level" do efeito Volume guarda amplitude linear onde 1.0 = +15 dB (0 dB = 0.1778)
function ft_gainOne(clip, db) {
  var prop = clip.components[0].properties[1];
  if (prop.isTimeVarying()) return "KEY";
  var cur = 20 * Math.log(prop.getValue()) / Math.LN10 + 15;
  var next = Math.min(15, cur + db);
  prop.setValue(Math.pow(10, (next - 15) / 20), true);
  return String(Math.round(next * 10) / 10);
}

function ft_addGain(nodeId, db) {
  try {
    var seq = app.project.activeSequence, res = "ERR:não achei o clipe";
    for (var i = 0; i < seq.audioTracks.numTracks; i++) {
      var t = seq.audioTracks[i];
      for (var j = 0; j < t.clips.numItems; j++) {
        if (t.clips[j].nodeId === nodeId) res = "OK:" + ft_gainOne(t.clips[j], db);
      }
    }
    return res;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

function ft_gainAll(db) {
  try {
    var seq = app.project.activeSequence, n = 0, key = 0;
    for (var i = 0; i < seq.audioTracks.numTracks; i++) {
      var t = seq.audioTracks[i];
      for (var j = 0; j < t.clips.numItems; j++) {
        if (ft_gainOne(t.clips[j], db) === "KEY") key++; else n++;
      }
    }
    return "OK:" + n + ":" + key;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// ---------- Edição: legendas, marcadores, silêncios ----------

function ft_addCaptions(srtPath, startSec, binPath) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:sem sequência ativa";
    var bin = ft_getBin(binPath);
    app.project.importFiles([srtPath], true, bin, false);
    var item = ft_findInBin(bin, srtPath);
    if (!item) {
      var want = new File(srtPath).displayName;
      for (var i = bin.children.numItems - 1; i >= 0 && !item; i--) {
        if (bin.children[i].name === want) item = bin.children[i];
      }
    }
    if (!item) return "ERR:não consegui importar o SRT";
    var ok = seq.createCaptionTrack(item, startSec, Sequence.CAPTION_FORMAT_SUBTITLE);
    return ok ? "OK" : "BIN";
  } catch (e) {
    return "BIN:" + e.toString();
  }
}

function ft_addMarkers(csv, name) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:sem sequência ativa";
    var times = csv.split(","), n = 0;
    for (var i = 0; i < times.length; i++) {
      var m = seq.markers.createMarker(Number(times[i]));
      m.name = name;
      n++;
    }
    return "OK:" + n;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

function ft_clearMarkers(name) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:sem sequência ativa";
    var list = [], m = seq.markers.getFirstMarker();
    while (m) {
      if (m.name === name) list.push(m);
      m = seq.markers.getNextMarker(m);
    }
    for (var i = 0; i < list.length; i++) seq.markers.deleteMarker(list[i]);
    return "OK:" + list.length;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

function ft_tc(seq, sec) {
  var t = new Time();
  t.ticks = String(Math.round(sec * FT_TICKS) + Number(seq.zeroPoint));
  return t.getFormatted(seq.getSettings().videoFrameRate, seq.getSettings().videoDisplayFormat);
}

// csv = "a-b;a-b" em segundos da sequência, em ordem. Corta com a navalha nas trilhas do clipe
// (vídeo e áudio ligados), levanta os pedaços de silêncio e puxa o resto para fechar os buracos.
function ft_cutSilences(csv, selStart, selEnd, backup) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:sem sequência ativa";
    if (backup === 1) { seq.clone(); seq = app.project.activeSequence; }
    app.enableQE();
    var qs = qe.project.getActiveSequence();
    var eps = Number(seq.timebase) / FT_TICKS * 0.6;

    var ranges = [], parts = csv.split(";"), i, j, k;
    for (i = 0; i < parts.length; i++) {
      var ab = parts[i].split("-");
      ranges.push([Number(ab[0]), Number(ab[1])]);
    }

    var targets = [];
    function scan(tracks, kind) {
      for (var a = 0; a < tracks.numTracks; a++) {
        for (var b = 0; b < tracks[a].clips.numItems; b++) {
          var c = tracks[a].clips[b];
          if (Math.abs(c.start.seconds - selStart) < eps && Math.abs(c.end.seconds - selEnd) < eps) {
            targets.push({ kind: kind, idx: a, track: tracks[a] });
            break;
          }
        }
      }
    }
    scan(seq.videoTracks, "v");
    scan(seq.audioTracks, "a");
    if (!targets.length) return "ERR:não achei o clipe na timeline";

    for (i = 0; i < ranges.length; i++) {
      for (j = 0; j < 2; j++) {
        var p = ranges[i][j];
        if (p <= selStart + eps || p >= selEnd - eps) continue;
        var tc = ft_tc(seq, p);
        for (k = 0; k < targets.length; k++) {
          var qt = targets[k].kind === "v" ? qs.getVideoTrackAt(targets[k].idx) : qs.getAudioTrackAt(targets[k].idx);
          qt.razor(tc);
        }
      }
    }

    var removed = 0;
    for (k = 0; k < targets.length; k++) {
      var clips = targets[k].track.clips, gone = [];
      for (j = clips.numItems - 1; j >= 0; j--) {
        var c = clips[j], s = c.start.seconds, e = c.end.seconds, mid = (s + e) / 2;
        if (mid < selStart || mid > selEnd) continue;
        for (i = 0; i < ranges.length; i++) {
          if (mid > ranges[i][0] && mid < ranges[i][1]) {
            gone.push([s, e]);
            c.remove(false, false);
            removed++;
            break;
          }
        }
      }
      // fecha os buracos: da esquerda para a direita, cada clipe anda o total já removido antes dele
      clips = targets[k].track.clips;
      for (j = 0; j < clips.numItems; j++) {
        var cs = clips[j].start.seconds, shift = 0;
        for (i = 0; i < gone.length; i++) {
          if (gone[i][1] <= cs + eps) shift += gone[i][1] - gone[i][0];
        }
        if (shift > 0) clips[j].move(ft_time(-shift));
      }
    }
    return "OK:" + removed + ":" + targets.length;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// ---------- Exportar ----------

function ft_launchAME() {
  try { app.encoder.launchEncoder(); return "OK"; } catch (e) { return "ERR:" + e.toString(); }
}

function ft_queue(outPath, presetPath, range) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:sem sequência ativa";
    var type = range === "inout" ? app.encoder.ENCODE_IN_TO_OUT : app.encoder.ENCODE_ENTIRE;
    var id = app.encoder.encodeSequence(seq, outPath, presetPath, type, 1);
    return id ? "OK:" + id : "ERR:o Media Encoder não aceitou o trabalho";
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

function ft_startBatch() {
  try { app.encoder.startBatch(); return "OK"; } catch (e) { return "ERR:" + e.toString(); }
}

// ---------- Legenda com estilo: clipe transparente acima de tudo ----------

// Importa e coloca na trilha de vídeo mais baixa que esteja livre dali para cima,
// para a legenda ficar sempre por cima do que já existe naquele trecho.
function ft_importTop(mediaPath, binPath, start, dur) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:sem sequência ativa";
    var bin = ft_getBin(binPath);
    app.project.importFiles([mediaPath], true, bin, false);
    var item = ft_findInBin(bin, mediaPath);
    if (!item) return "ERR:não consegui importar";
    var n = seq.videoTracks.numTracks, pick = n;
    for (var i = n - 1; i >= 0; i--) {
      if (!ft_trackFree(seq.videoTracks[i], start, start + dur)) break;
      pick = i;
    }
    if (pick === n) {
      ft_addVideoAndAudioTrack(seq);
      pick = seq.videoTracks.numTracks - 1;
    }
    seq.videoTracks[pick].overwriteClip(item, ft_time(start));
    return "OK:V" + (pick + 1);
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// ---------- Marcar (decupagem) ----------

function ft_tagSet(tagsCsv) {
  var set = {}, list = tagsCsv.split("|");
  for (var i = 0; i < list.length; i++) set[list[i]] = true;
  return set;
}

// Apaga marcadores de decupagem que cobrem exatamente o trecho [s, e]
function ft_removeSpanMarkers(seq, s, e, set) {
  var eps = Number(seq.timebase) / FT_TICKS * 0.6, list = [], m = seq.markers.getFirstMarker();
  while (m) {
    if (set[m.name] && Math.abs(m.start.seconds - s) < eps && Math.abs(m.end.seconds - e) < eps) list.push(m);
    m = seq.markers.getNextMarker(m);
  }
  for (var i = 0; i < list.length; i++) seq.markers.deleteMarker(list[i]);
  return list.length;
}

function ft_plainName(name) { return String(name).replace(/^\[[^\]]*\]\s*/, ""); }

// Cada bloco selecionado ganha um marcador de sequência do tamanho dele (nome e cor do tipo)
// e, se pedido, o tipo entre colchetes no nome. Vídeo e áudio ligados contam como um bloco só.
// Sem seleção, entra um marcador simples no playhead.
function ft_tagSelection(tag, colorIdx, doMarker, doName, tagsCsv) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:Abra uma sequência";
    var sel = seq.getSelection(), set = ft_tagSet(tagsCsv), m;
    if (!sel || sel.length === 0) {
      m = seq.markers.createMarker(seq.getPlayerPosition().seconds);
      m.name = tag;
      m.setColorByIndex(colorIdx);
      return "OK:0:1";
    }
    var seen = {}, blocks = 0;
    for (var i = 0; i < sel.length; i++) {
      var c = sel[i], s = c.start.seconds, e = c.end.seconds, key = s.toFixed(3) + "-" + e.toFixed(3);
      var plain = ft_plainName(c.name);
      if (!seen[key]) {
        seen[key] = true;
        blocks++;
        ft_removeSpanMarkers(seq, s, e, set);
        if (doMarker === 1) {
          m = seq.markers.createMarker(s);
          m.name = tag;
          m.comments = plain;
          m.end = e;
          m.setColorByIndex(colorIdx);
        }
      }
      if (doName === 1) c.name = "[" + tag + "] " + plain;
    }
    return "OK:" + blocks + ":0";
  } catch (e2) {
    return "ERR:" + e2.toString();
  }
}

function ft_untagSelection(tagsCsv) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:Abra uma sequência";
    var sel = seq.getSelection(), set = ft_tagSet(tagsCsv), n = 0;
    if (!sel || sel.length === 0) return "ERR:Selecione os clipes na timeline";
    for (var i = 0; i < sel.length; i++) {
      var c = sel[i], plain = ft_plainName(c.name);
      n += ft_removeSpanMarkers(seq, c.start.seconds, c.end.seconds, set);
      if (plain !== c.name) c.name = plain;
    }
    return "OK:" + sel.length + ":" + n;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

function ft_listTagged(tagsCsv) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return '{"err":"Abra uma sequência"}';
    var set = ft_tagSet(tagsCsv), out = [], m = seq.markers.getFirstMarker();
    while (m) {
      if (set[m.name]) out.push('{"name":' + ft_q(m.name) + ',"start":' + m.start.seconds + ',"end":' + m.end.seconds + ',"clip":' + ft_q(m.comments) + '}');
      m = seq.markers.getNextMarker(m);
    }
    return '{"name":' + ft_q(seq.name) + ',"items":[' + out.join(",") + ']}';
  } catch (e) {
    return '{"err":' + ft_q(e.toString()) + '}';
  }
}

// ---------- Keyframes (volume e zoom) ----------

// Os tempos de keyframe de um clipe contam a partir do início da mídia, não da sequência
function ft_mediaTime(clip, seqSec) { return clip.inPoint.seconds + (seqSec - clip.start.seconds); }

// Tenta com segundos; se o Premiere não aceitar, tenta com objetos Time
function ft_setKeys(prop, times, values) {
  var i, keys;
  prop.setTimeVarying(true);
  for (i = 0; i < times.length; i++) {
    prop.addKey(times[i]);
    prop.setValueAtKey(times[i], values[i], i === times.length - 1);
  }
  keys = prop.getKeys();
  if (keys && keys.length >= times.length) return true;
  for (i = 0; i < times.length; i++) {
    var t = ft_time(times[i]);
    prop.addKey(t);
    prop.setValueAtKey(t, values[i], true);
  }
  keys = prop.getKeys();
  return !!(keys && keys.length);
}

function ft_keyExtreme(prop, wantMax) {
  var keys = prop.getKeys(), best = null;
  for (var i = 0; keys && i < keys.length; i++) {
    var v = Number(prop.getValueAtKey(keys[i]));
    if (best === null || (wantMax ? v > best : v < best)) best = v;
  }
  return best;
}

// ---------- Trilha na fala ----------

function ft_audioTracks() {
  var seq = app.project.activeSequence;
  if (!seq) return '{"err":"Abra uma sequência"}';
  var out = [];
  for (var i = 0; i < seq.audioTracks.numTracks; i++) out.push('{"i":' + i + ',"n":' + seq.audioTracks[i].clips.numItems + '}');
  return '{"tracks":[' + out.join(",") + ']}';
}

function ft_trackClips(idx) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return '{"err":"Abra uma sequência"}';
    if (idx >= seq.audioTracks.numTracks) return '{"err":"Essa trilha não existe na sequência"}';
    var t = seq.audioTracks[idx], out = [];
    for (var j = 0; j < t.clips.numItems; j++) {
      var c = t.clips[j];
      if (c.disabled || !c.projectItem || !c.projectItem.getMediaPath()) continue;
      out.push(ft_clipJson(c));
    }
    return '{"clips":[' + out.join(",") + ']}';
  } catch (e) {
    return '{"err":' + ft_q(e.toString()) + '}';
  }
}

// csv = "t:f;t:f" em segundos da sequência; f=1 volume normal, f=0 volume abaixado em `db`
function ft_duck(nodeId, csv, db, voiceIdx) {
  try {
    var seq = app.project.activeSequence, clip = null, i, j;
    for (i = 0; i < seq.audioTracks.numTracks && !clip; i++) {
      var t = seq.audioTracks[i];
      for (j = 0; j < t.clips.numItems; j++) {
        if (t.clips[j].nodeId === nodeId) {
          if (i === voiceIdx) return "OK:SAME";
          clip = t.clips[j];
          break;
        }
      }
    }
    if (!clip) return "ERR:não achei o clipe";
    var prop = clip.components[0].properties[1];
    if (prop.isTimeVarying()) return "OK:KEY";
    var base = Number(prop.getValue()), low = base * Math.pow(10, -db / 20);
    var parts = csv.split(";"), times = [], values = [];
    for (i = 0; i < parts.length; i++) {
      var tf = parts[i].split(":");
      times.push(ft_mediaTime(clip, Number(tf[0])));
      values.push(tf[1] === "1" ? base : low);
    }
    if (!ft_setKeys(prop, times, values)) {
      prop.setTimeVarying(false);
      prop.setValue(base, true);
      return "ERR:o Premiere não aceitou os keyframes";
    }
    return "OK:" + times.length;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// Tira os keyframes de volume dos clipes de áudio selecionados e volta ao volume mais alto que havia
function ft_unduck() {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:Abra uma sequência";
    var sel = seq.getSelection(), n = 0;
    for (var i = 0; sel && i < sel.length; i++) {
      if (sel[i].mediaType !== "Audio") continue;
      var prop = sel[i].components[0].properties[1];
      if (!prop.isTimeVarying()) continue;
      var base = ft_keyExtreme(prop, true);
      prop.setTimeVarying(false);
      if (base !== null) prop.setValue(base, true);
      n++;
    }
    return "OK:" + n;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// ---------- Zoom ----------

function ft_motionScale(clip) {
  for (var i = 0; i < clip.components.numItems; i++) {
    if (clip.components[i].matchName === "AE.ADBE Motion") return clip.components[i].properties[1];
  }
  return null;
}

function ft_baseMap(csv) {
  var map = {}, list = csv ? csv.split("|") : [];
  for (var i = 0; i < list.length; i++) {
    var kv = list[i].split("=");
    map[kv[0]] = Number(kv[1]);
  }
  return map;
}

// style: "in" aproxima devagar, "out" afasta devagar, "punch" trecho inteiro com zoom, "inout" entra e sai.
// basesCsv = "nodeId=escala|…" com a escala original dos clipes que já receberam zoom.
function ft_zoom(style, pct, basesCsv) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:Abra uma sequência";
    var sel = seq.getSelection(), known = ft_baseMap(basesCsv), out = [], n = 0;
    for (var i = 0; sel && i < sel.length; i++) {
      var c = sel[i];
      if (c.mediaType !== "Video") continue;
      var prop = ft_motionScale(c);
      if (!prop) continue;
      var base = known[c.nodeId];
      if (!base) base = prop.isTimeVarying() ? ft_keyExtreme(prop, false) : Number(prop.getValue());
      if (prop.isTimeVarying()) prop.setTimeVarying(false);
      var z = base * pct / 100, a = c.inPoint.seconds, b = c.outPoint.seconds, d = b - a, times, values;
      if (style === "punch") {
        prop.setValue(z, true);
      } else {
        if (style === "in") { times = [a, b]; values = [base, z]; }
        else if (style === "out") { times = [a, b]; values = [z, base]; }
        else { var r = Math.min(0.5, d / 3); times = [a, a + r, b - r, b]; values = [base, z, z, base]; }
        if (!ft_setKeys(prop, times, values)) {
          prop.setTimeVarying(false);
          prop.setValue(base, true);
          return "ERR:o Premiere não aceitou os keyframes";
        }
        if (style === "inout") {
          try {
            var keys = prop.getKeys();
            for (var k = 0; k < keys.length; k++) prop.setInterpolationTypeAtKey(keys[k], 5, k === keys.length - 1);
          } catch (e1) {}
        }
      }
      out.push(c.nodeId + "=" + base);
      n++;
    }
    if (!n) return "ERR:Selecione um ou mais clipes de vídeo na timeline";
    return "OK:" + n + ":" + out.join("|");
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

function ft_unzoom(basesCsv) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:Abra uma sequência";
    var sel = seq.getSelection(), known = ft_baseMap(basesCsv), n = 0, skipped = 0;
    for (var i = 0; sel && i < sel.length; i++) {
      var c = sel[i];
      if (c.mediaType !== "Video") continue;
      var prop = ft_motionScale(c);
      if (!prop) continue;
      var base = known[c.nodeId];
      if (!base && prop.isTimeVarying()) base = ft_keyExtreme(prop, false);
      if (!base) { skipped++; continue; }
      if (prop.isTimeVarying()) prop.setTimeVarying(false);
      prop.setValue(base, true);
      n++;
    }
    return "OK:" + n + ":" + skipped;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// ---------- Versões (reenquadrar) ----------

function ft_reframe(num, den, name, motion, outPath, presetPath) {
  try {
    var orig = app.project.activeSequence;
    if (!orig) return "ERR:Abra uma sequência";
    var r = orig.autoReframeSequence(num, den, motion, name, false), neu = null;
    if (r && r.name) neu = r;
    for (var i = app.project.sequences.numSequences - 1; i >= 0 && !neu; i--) {
      if (app.project.sequences[i].name === name) neu = app.project.sequences[i];
    }
    if (!neu) return "ERR:o Premiere não criou a versão " + name;
    var queued = 0;
    if (outPath) {
      if (app.encoder.encodeSequence(neu, outPath, presetPath, app.encoder.ENCODE_ENTIRE, 1)) queued = 1;
    }
    try { app.project.activeSequence = orig; } catch (e1) {}
    return "OK:" + queued;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// ---------- Conferir antes de entregar ----------

function ft_check() {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return '{"err":"Abra uma sequência"}';
    var frame = Number(seq.timebase) / FT_TICKS, end = Number(seq.end) / FT_TICKS;
    var spans = [], off = [], tiny = [], seenOff = {}, i, j, c, s, e;
    function offline(clip) {
      try {
        if (clip.projectItem && clip.projectItem.isOffline()) {
          var key = clip.name + "@" + clip.start.seconds.toFixed(2);
          if (!seenOff[key]) { seenOff[key] = true; off.push('{"name":' + ft_q(clip.name) + ',"t":' + clip.start.seconds + '}'); }
        }
      } catch (e1) {}
    }
    for (i = 0; i < seq.videoTracks.numTracks; i++) {
      for (j = 0; j < seq.videoTracks[i].clips.numItems; j++) {
        c = seq.videoTracks[i].clips[j];
        if (c.disabled) continue;
        s = c.start.seconds; e = c.end.seconds;
        spans.push([s, e]);
        if (e - s < frame * 2.5) tiny.push('{"name":' + ft_q(c.name) + ',"t":' + s + ',"track":' + (i + 1) + '}');
        offline(c);
      }
    }
    for (i = 0; i < seq.audioTracks.numTracks; i++) {
      for (j = 0; j < seq.audioTracks[i].clips.numItems; j++) {
        c = seq.audioTracks[i].clips[j];
        if (!c.disabled) offline(c);
      }
    }
    spans.sort(function (x, y) { return x[0] - y[0]; });
    var gaps = [], cur = 0;
    for (i = 0; i < spans.length; i++) {
      if (spans[i][0] > cur + frame * 0.5) gaps.push("[" + cur + "," + spans[i][0] + "]");
      if (spans[i][1] > cur) cur = spans[i][1];
    }
    if (end > cur + frame * 0.5) gaps.push("[" + cur + "," + end + "]");
    return '{"name":' + ft_q(seq.name) + ',"dur":' + end + ',"clips":' + spans.length +
      ',"gaps":[' + gaps.join(",") + '],"offline":[' + off.join(",") + '],"tiny":[' + tiny.join(",") + ']}';
  } catch (e2) {
    return '{"err":' + ft_q(e2.toString()) + '}';
  }
}

function ft_goto(sec) {
  try {
    app.project.activeSequence.setPlayerPosition(String(Math.round(sec * FT_TICKS)));
    return "OK";
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// ---------- Sincronizar pelo som e corte por quem fala ----------

function ft_selAudioWithTrack() {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return '{"err":"Abra uma sequência"}';
    var out = [];
    for (var i = 0; i < seq.audioTracks.numTracks; i++) {
      var t = seq.audioTracks[i];
      for (var j = 0; j < t.clips.numItems; j++) {
        var c = t.clips[j];
        if (c.isSelected() && c.projectItem && c.projectItem.getMediaPath()) out.push(ft_clipJson(c).replace(/\}$/, ',"track":' + i + '}'));
      }
    }
    return '{"clips":[' + out.join(",") + ']}';
  } catch (e) {
    return '{"err":' + ft_q(e.toString()) + '}';
  }
}

// Anda com o bloco (vídeo e áudio que começam e terminam juntos) em `delta` segundos
function ft_moveBlock(start, end, delta) {
  try {
    var seq = app.project.activeSequence;
    var eps = Number(seq.timebase) / FT_TICKS * 0.6, list = [], i;
    function scan(tracks) {
      for (var a = 0; a < tracks.numTracks; a++) {
        for (var b = 0; b < tracks[a].clips.numItems; b++) {
          var c = tracks[a].clips[b];
          if (Math.abs(c.start.seconds - start) < eps && Math.abs(c.end.seconds - end) < eps) list.push(c);
        }
      }
    }
    scan(seq.videoTracks);
    scan(seq.audioTracks);
    // se o Premiere já levou junto a parte ligada, ela não está mais no lugar antigo e não anda de novo
    for (i = 0; i < list.length; i++) {
      if (Math.abs(list[i].start.seconds - start) < eps) list[i].move(ft_time(delta));
    }
    return "OK:" + list.length;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// Clipe de vídeo selecionado na trilha mais alta
function ft_selectedVideo() {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return '{"err":"Abra uma sequência"}';
    for (var i = seq.videoTracks.numTracks - 1; i >= 0; i--) {
      var t = seq.videoTracks[i];
      for (var j = 0; j < t.clips.numItems; j++) {
        var c = t.clips[j];
        if (c.isSelected()) {
          return '{"track":' + i + ',"name":' + ft_q(c.name) + ',"start":' + c.start.seconds + ',"end":' + c.end.seconds +
            ',"frame":' + (Number(seq.timebase) / FT_TICKS) + '}';
        }
      }
    }
    return '{"err":"Selecione o clipe de vídeo da câmera de cima"}';
  } catch (e) {
    return '{"err":' + ft_q(e.toString()) + '}';
  }
}

// csv = "a-b;a-b": trechos em que a câmera de cima deve sumir. Corta só a trilha dela e
// desativa os pedaços desses trechos, deixando aparecer a câmera de baixo. Nada é apagado.
function ft_camCut(trackIdx, selStart, selEnd, csv) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return "ERR:sem sequência ativa";
    app.enableQE();
    var qt = qe.project.getActiveSequence().getVideoTrackAt(trackIdx);
    var eps = Number(seq.timebase) / FT_TICKS * 0.6;
    var ranges = [], parts = csv ? csv.split(";") : [], i, j;
    for (i = 0; i < parts.length; i++) {
      var ab = parts[i].split("-");
      ranges.push([Number(ab[0]), Number(ab[1])]);
    }
    for (i = 0; i < ranges.length; i++) {
      for (j = 0; j < 2; j++) {
        var p = ranges[i][j];
        if (p > selStart + eps && p < selEnd - eps) qt.razor(ft_tc(seq, p));
      }
    }
    var clips = seq.videoTracks[trackIdx].clips, total = 0, hidden = 0;
    for (j = 0; j < clips.numItems; j++) {
      var c = clips[j], mid = (c.start.seconds + c.end.seconds) / 2, hide = false;
      if (mid < selStart || mid > selEnd) continue;
      for (i = 0; i < ranges.length; i++) {
        if (mid > ranges[i][0] && mid < ranges[i][1]) { hide = true; break; }
      }
      c.disabled = hide;
      total++;
      if (hide) hidden++;
    }
    return "OK:" + total + ":" + hidden;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}

// ---------- Borrar ----------

// Clipe de vídeo selecionado (o da trilha mais alta), com o arquivo e a posição do playhead
function ft_selectedVideoClip() {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return '{"err":"Abra uma sequência"}';
    for (var i = seq.videoTracks.numTracks - 1; i >= 0; i--) {
      var t = seq.videoTracks[i];
      for (var j = 0; j < t.clips.numItems; j++) {
        var c = t.clips[j];
        if (!c.isSelected()) continue;
        if (!c.projectItem || !c.projectItem.getMediaPath()) return '{"err":"Esse clipe não tem arquivo de vídeo (gráfico ou sequência aninhada)"}';
        return ft_clipJson(c).replace(/\}$/, ',"track":' + i + ',"playhead":' + seq.getPlayerPosition().seconds +
          ',"frame":' + (Number(seq.timebase) / FT_TICKS) + '}');
      }
    }
    return '{"err":"Selecione um clipe de vídeo na timeline"}';
  } catch (e) {
    return '{"err":' + ft_q(e.toString()) + '}';
  }
}

function ft_motion(clip) {
  for (var i = 0; i < clip.components.numItems; i++) {
    if (clip.components[i].matchName === "AE.ADBE Motion") return clip.components[i];
  }
  return null;
}

// Posição, escala, rotação e ponto de ancoragem do clipe original, para o borrão cair no mesmo lugar
function ft_copyMotion(src, dst) {
  var a = ft_motion(src), b = ft_motion(dst), idx = [0, 1, 4, 5];
  if (!a || !b) return;
  for (var n = 0; n < idx.length; n++) {
    try {
      var pa = a.properties[idx[n]], pb = b.properties[idx[n]];
      if (pa.isTimeVarying()) {
        var keys = pa.getKeys(), times = [], values = [];
        for (var k = 0; k < keys.length; k++) {
          times.push(keys[k].seconds - src.inPoint.seconds + dst.inPoint.seconds);
          values.push(pa.getValueAtKey(keys[k]));
        }
        ft_setKeys(pb, times, values);
      } else {
        pb.setValue(pa.getValue(), true);
      }
    } catch (e) {}
  }
}

// Coloca o arquivo por cima de tudo no trecho e copia o enquadramento do clipe original
function ft_placeOver(mediaPath, binPath, start, dur, srcNodeId) {
  try {
    var res = ft_importTop(mediaPath, binPath, start, dur);
    if (res.indexOf("OK:V") !== 0) return res;
    var seq = app.project.activeSequence, track = seq.videoTracks[Number(res.substr(4)) - 1];
    var eps = Number(seq.timebase) / FT_TICKS * 0.6, dst = null, src = null, i, j;
    for (j = 0; j < track.clips.numItems; j++) {
      if (Math.abs(track.clips[j].start.seconds - start) < eps) dst = track.clips[j];
    }
    for (i = 0; i < seq.videoTracks.numTracks && !src; i++) {
      for (j = 0; j < seq.videoTracks[i].clips.numItems; j++) {
        if (seq.videoTracks[i].clips[j].nodeId === srcNodeId) { src = seq.videoTracks[i].clips[j]; break; }
      }
    }
    if (src && dst) ft_copyMotion(src, dst);
    return res;
  } catch (e) {
    return "ERR:" + e.toString();
  }
}
