// Síntese de SFX sem dependências: cada tipo é uma função pura de (duração, semente) -> [L, R]
(function (root) {
  const SR = 48000;

  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const lerp = (a, b, t) => a + (b - a) * t;
  const expLerp = (a, b, t) => a * Math.pow(b / a, t);

  // Filtro de estado variável (TPT): devolve low/band/high por amostra
  function svf() {
    let ic1 = 0, ic2 = 0;
    return function (x, fc, q) {
      const g = Math.tan(Math.PI * Math.min(fc, SR * 0.45) / SR);
      const k = 1 / q;
      const a1 = 1 / (1 + g * (g + k)), a2 = g * a1, a3 = g * a2;
      const v3 = x - ic2;
      const v1 = a1 * ic1 + a2 * v3;
      const v2 = ic2 + a2 * ic1 + a3 * v3;
      ic1 = 2 * v1 - ic1;
      ic2 = 2 * v2 - ic2;
      return { low: v2, band: v1, high: x - k * v1 - v2 };
    };
  }

  function buffers(dur) {
    const n = Math.max(1, Math.round(dur * SR));
    return [new Float32Array(n), new Float32Array(n)];
  }

  const types = {
    whoosh(dur, r) {
      const [L, R] = buffers(dur);
      const fL = svf(), fR = svf();
      const f0 = lerp(180, 400, r()), fPeak = lerp(1800, 5000, r());
      const peakAt = lerp(0.4, 0.65, r()), q = lerp(1.2, 3, r());
      const panDir = r() < 0.5 ? -1 : 1;
      for (let i = 0; i < L.length; i++) {
        const t = i / L.length;
        const shape = t < peakAt ? t / peakAt : 1 - (t - peakAt) / (1 - peakAt);
        const fc = expLerp(f0, fPeak, Math.pow(shape, 1.5));
        const env = Math.pow(Math.sin(Math.PI * Math.min(1, Math.max(0, shape)) / 2), 2.2);
        const common = r() * 2 - 1;
        const nl = 0.7 * common + 0.3 * (r() * 2 - 1);
        const nr = 0.7 * common + 0.3 * (r() * 2 - 1);
        const pan = panDir * (t * 2 - 1) * 0.6;
        L[i] = fL(nl, fc, q).band * env * (1 - pan);
        R[i] = fR(nr, fc, q).band * env * (1 + pan);
      }
      return [L, R];
    },

    impact(dur, r) {
      const [L, R] = buffers(dur);
      const fn = svf();
      const fStart = lerp(120, 200, r()), fEnd = lerp(38, 55, r());
      const decay = lerp(3, 7, r()) / dur;
      const noiseAmt = lerp(0.3, 0.8, r());
      let ph = 0;
      for (let i = 0; i < L.length; i++) {
        const s = i / SR;
        const f = fEnd + (fStart - fEnd) * Math.exp(-s * 30);
        ph += 2 * Math.PI * f / SR;
        const body = Math.sin(ph) * Math.exp(-s * decay);
        const crack = fn(r() * 2 - 1, lerp(5000, 900, Math.min(1, s * 8)), 0.8).low * Math.exp(-s * 25) * noiseAmt;
        const v = Math.tanh((body + crack) * 2.2);
        L[i] = v; R[i] = v;
      }
      return [L, R];
    },

    riser(dur, r) {
      const [L, R] = buffers(dur);
      const fL = svf(), fR = svf();
      const tone0 = lerp(80, 140, r()), tone1 = lerp(500, 1100, r());
      const vib = lerp(4, 8, r());
      let ph = 0, ph2 = 0;
      for (let i = 0; i < L.length; i++) {
        const t = i / L.length;
        const env = Math.pow(t, 2.4) * (t > 0.985 ? (1 - t) / 0.015 : 1);
        const fc = expLerp(200, 9000, t);
        const f = expLerp(tone0, tone1, t) * (1 + 0.01 * Math.sin(2 * Math.PI * vib * i / SR));
        ph += 2 * Math.PI * f / SR;
        ph2 += 2 * Math.PI * f * 1.005 / SR;
        const saw = ((ph / Math.PI) % 2) - 1, saw2 = ((ph2 / Math.PI) % 2) - 1;
        L[i] = (fL(r() * 2 - 1, fc, 1.5).band * 0.8 + saw * 0.25) * env;
        R[i] = (fR(r() * 2 - 1, fc, 1.5).band * 0.8 + saw2 * 0.25) * env;
      }
      return [L, R];
    },

    reverse(dur, r) {
      const [L, R] = buffers(dur);
      const fL = svf(), fR = svf();
      const fc0 = lerp(3000, 6000, r()), curve = lerp(3, 6, r());
      for (let i = 0; i < L.length; i++) {
        const t = i / L.length;
        const env = Math.pow(t, curve) * (t > 0.995 ? 0 : 1);
        const fc = lerp(fc0, 12000, t);
        L[i] = fL(r() * 2 - 1, fc, 0.7).high * env;
        R[i] = fR(r() * 2 - 1, fc, 0.7).high * env;
      }
      return [L, R];
    },

    subdrop(dur, r) {
      const [L, R] = buffers(dur);
      const f0 = lerp(100, 160, r()), f1 = lerp(28, 40, r());
      let ph = 0;
      for (let i = 0; i < L.length; i++) {
        const t = i / L.length;
        ph += 2 * Math.PI * expLerp(f0, f1, Math.pow(t, 0.6)) / SR;
        const env = Math.min(1, i / (SR * 0.005)) * Math.pow(1 - t, 1.3);
        const v = Math.tanh(Math.sin(ph) * 1.6) * env;
        L[i] = v; R[i] = v;
      }
      return [L, R];
    },

    pop(dur, r) {
      const [L, R] = buffers(dur);
      const f0 = lerp(700, 1600, r()), f1 = lerp(150, 300, r());
      const sweep = lerp(0.02, 0.06, r());
      let ph = 0;
      for (let i = 0; i < L.length; i++) {
        const s = i / SR;
        ph += 2 * Math.PI * expLerp(f0, f1, Math.min(1, s / sweep)) / SR;
        const env = Math.min(1, s / 0.001) * Math.exp(-s / (sweep * 1.2));
        const v = Math.sin(ph) * env;
        L[i] = v; R[i] = v;
      }
      return [L, R];
    },

    glitch(dur, r) {
      const [L, R] = buffers(dur);
      let i = 0;
      while (i < L.length) {
        const len = Math.round(SR * lerp(0.01, 0.07, r()));
        const kind = Math.floor(r() * 4);
        const f = lerp(80, 3000, r()), crush = Math.floor(lerp(2, 16, r()));
        const amp = lerp(0.4, 1, r()), side = r() < 0.5;
        let hold = 0;
        for (let j = 0; j < len && i < L.length; j++, i++) {
          let v = 0;
          if (kind === 0) v = Math.sign(Math.sin(2 * Math.PI * f * j / SR));
          else if (kind === 1) { if (j % crush === 0) hold = r() * 2 - 1; v = hold; }
          else if (kind === 2) v = Math.sin(2 * Math.PI * f * j / SR) * (j % 400 < 200 ? 1 : 0);
          v *= amp;
          L[i] = side ? v : v * 0.6;
          R[i] = side ? v * 0.6 : v;
        }
      }
      return [L, R];
    },

    ding(dur, r) {
      const [L, R] = buffers(dur);
      const f = lerp(700, 1400, r());
      const partials = [[1, 1, 1], [2.76, 0.45, 1.8], [5.4, 0.2, 3.2], [8.93, 0.08, 5]];
      const decay = lerp(2.5, 5, r()) / dur;
      for (let i = 0; i < L.length; i++) {
        const s = i / SR;
        let v = 0;
        for (const [m, a, d] of partials) v += Math.sin(2 * Math.PI * f * m * s) * a * Math.exp(-s * decay * d);
        v *= Math.min(1, s / 0.002);
        L[i] = v; R[i] = v * 0.97;
      }
      return [L, R];
    },
  };

  function normalize([L, R], peakDb) {
    let m = 0;
    for (let i = 0; i < L.length; i++) m = Math.max(m, Math.abs(L[i]), Math.abs(R[i]));
    const g = m > 0 ? Math.pow(10, peakDb / 20) / m : 1;
    for (let i = 0; i < L.length; i++) { L[i] *= g; R[i] *= g; }
    // micro fade para não estalar no fim
    const fade = Math.min(L.length, Math.round(SR * 0.004));
    for (let i = 0; i < fade; i++) { const k = i / fade; L[L.length - 1 - i] *= k; R[R.length - 1 - i] *= k; }
    return [L, R];
  }

  // WAV estéreo 24 bits
  function toWav([L, R]) {
    const n = L.length, bytes = n * 6;
    const buf = new ArrayBuffer(44 + bytes);
    const dv = new DataView(buf);
    const str = (o, s) => { for (let i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); };
    str(0, "RIFF"); dv.setUint32(4, 36 + bytes, true); str(8, "WAVE");
    str(12, "fmt "); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 2, true);
    dv.setUint32(24, SR, true); dv.setUint32(28, SR * 6, true); dv.setUint16(32, 6, true); dv.setUint16(34, 24, true);
    str(36, "data"); dv.setUint32(40, bytes, true);
    let o = 44;
    for (let i = 0; i < n; i++) {
      for (const ch of [L, R]) {
        const v = Math.max(-1, Math.min(1, ch[i])) * 8388607 | 0;
        dv.setUint8(o, v & 255); dv.setUint8(o + 1, (v >> 8) & 255); dv.setUint8(o + 2, (v >> 16) & 255);
        o += 3;
      }
    }
    return new Uint8Array(buf);
  }

  function render(type, dur, seed) {
    if (!types[type]) throw new Error("Tipo desconhecido: " + type);
    return toWav(normalize(types[type](dur, rng(seed)), -1));
  }

  const api = { render, types: Object.keys(types), SR };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.FTSynth = api;
})(typeof window !== "undefined" ? window : globalThis);
