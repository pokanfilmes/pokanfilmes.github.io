// Pokan Tools — borrar rostos ou uma área marcada, com o borrão seguindo o movimento
// Usa os utilitários de main.js e extras.js

const YUNET = path.join(TOOLS, "models/face_detection_yunet_2023mar.onnx");
const blurSel = { nodeId: null, t0: 0, box: null }; // área marcada: em qual clipe, em que instante e onde (0 a 1)

async function selectedVideoClip() {
  const c = JSON.parse(await jsx("ft_selectedVideoClip()"));
  if (c.err) throw new Error(c.err);
  return c;
}

// Tamanho do quadro como ele aparece (vídeo de celular costuma vir deitado com aviso de rotação)
async function probeVideo(file) {
  const s = JSON.parse(await run(BIN.ffprobe, ["-v", "error", "-select_streams", "v:0", "-show_streams", "-of", "json", file])).streams[0];
  if (!s) throw new Error("Esse arquivo não tem vídeo.");
  let rot = Number((s.tags || {}).rotate || 0);
  (s.side_data_list || []).forEach((d) => { if (d.rotation != null) rot = Number(d.rotation); });
  const turned = Math.abs(rot) % 180 === 90;
  return { w: turned ? s.height : s.width, h: turned ? s.width : s.height };
}

function drawBlurBox() {
  const el = $("bl-box"), b = blurSel.box;
  el.classList.toggle("hidden", !b);
  if (!b) return;
  el.style.left = b[0] * 100 + "%";
  el.style.top = b[1] * 100 + "%";
  el.style.width = b[2] * 100 + "%";
  el.style.height = b[3] * 100 + "%";
}

$("bl-mode").addEventListener("change", () => $("bl-area").classList.toggle("hidden", $("bl-mode").value !== "area"));

$("bl-show").addEventListener("click", () => guard(null, async () => {
  const c = await selectedVideoClip();
  const t0 = Math.max(0, Math.min(c.end - c.start - c.frame, c.playhead - c.start));
  const jpg = path.join(os.tmpdir(), `pt_quadro_${Date.now()}.jpg`);
  await run(BIN.ffmpeg, ["-y", "-ss", String(c.inPoint + t0), "-i", c.path, "-frames:v", "1", "-vf", "scale=640:-2", "-q:v", "4", jpg]);
  $("bl-img").src = "file://" + encodeURI(jpg);
  $("bl-frame").classList.remove("hidden");
  blurSel.nodeId = c.nodeId;
  blurSel.t0 = t0;
  blurSel.box = null;
  drawBlurBox();
  status(c.playhead < c.start || c.playhead > c.end ? "O playhead está fora do clipe: mostrei o primeiro quadro. Arraste um retângulo em volta da área." : "Arraste um retângulo em volta da área.");
}));

(function dragBox() {
  const frame = $("bl-frame");
  let from = null;
  const at = (e) => {
    const r = frame.getBoundingClientRect();
    return [Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)), Math.max(0, Math.min(1, (e.clientY - r.top) / r.height))];
  };
  const update = (e) => {
    const p = at(e);
    blurSel.box = [Math.min(from[0], p[0]), Math.min(from[1], p[1]), Math.abs(p[0] - from[0]), Math.abs(p[1] - from[1])];
    drawBlurBox();
  };
  frame.addEventListener("mousedown", (e) => { from = at(e); e.preventDefault(); });
  window.addEventListener("mousemove", (e) => { if (from) update(e); });
  window.addEventListener("mouseup", (e) => {
    if (!from) return;
    update(e);
    from = null;
    if (blurSel.box[2] < 0.02 || blurSel.box[3] < 0.02) { blurSel.box = null; drawBlurBox(); }
  });
})();

$("bl-go").addEventListener("click", () => guard($("bl-go"), async () => {
  const c = await selectedVideoClip(), mode = $("bl-mode").value;
  if (!fs.existsSync(YUNET)) throw new Error("Falta o detector de rostos. Rode o instalador do Pokan Tools de novo.");
  if (mode === "area" && (!blurSel.box || blurSel.nodeId !== c.nodeId)) throw new Error("Marque a área primeiro: mostre o quadro do playhead e arraste um retângulo nesse clipe.");
  const info = await seqInfo(), size = await probeVideo(c.path), dur = c.end - c.start;
  const out = path.join(await outDir("Borrao"), `${baseOf(c.name)}_borrao_${stampNow()}.mov`);
  const args = [pyScript("borrar.py"), BIN.ffmpeg, c.path, String(c.inPoint), String(dur), fpsArg(info.frame), String(size.w), String(size.h), out, mode, $("bl-strength").value, YUNET];
  if (mode === "area") args.push(...blurSel.box.map((v) => v.toFixed(5)), blurSel.t0.toFixed(4));
  status(mode === "rostos" ? "Procurando rostos…" : "Seguindo a área…");
  progress(1);
  let frames = 0, lost = -1;
  await run(BIN.python, args, (l) => {
    const p = l.match(/^PT (\d+)/), ok = l.match(/^OK (\d+) (-?[\d.]+)/);
    if (p) { progress(Number(p[1])); status((Number(p[1]) < 40 ? (mode === "rostos" ? "Procurando rostos… " : "Seguindo a área… ") : "Desenhando o borrão… ") + p[1] + "%"); }
    if (ok) { frames = Number(ok[1]); lost = parseFloat(ok[2]); }
  });
  if (!frames) {
    fs.unlink(out, () => {});
    throw new Error(mode === "rostos" ? "Não achei nenhum rosto nesse clipe." : "Não consegui seguir a área marcada.");
  }
  const res = okRes(await jsx(`ft_placeOver(${lit(out)}, "Pokan Tools/Borrao", ${c.start}, ${dur}, ${lit(c.nodeId)})`), "Borrar");
  status(`Pronto: borrão na trilha ${res.replace("OK:", "")}` + (lost >= 0 ? `. A área saiu de vista em ${clock(c.start + lost)}; confira dali em diante.` : ". Assista ao trecho para conferir."));
}));
