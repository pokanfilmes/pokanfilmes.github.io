// Pokan Tools — busca pela fala, vícios de fala, sincronia pelo som, corte por quem fala e ortografia
// Usa os utilitários de main.js, extras.js e mais.js

const crypto = require("crypto");

// ---------- TRANSCRIÇÃO COM PALAVRAS ----------

const wordsMem = {}; // transcrições da sequência inteira, só enquanto o painel está aberto

// Palavras com tempo, em segundos da sequência. A do clipe fica guardada em arquivo.
async function getWords(scope) {
  const model = $("cp-model").value, lang = $("cp-lang").value;
  let c = null, start = 0, file, memKey = null, raw;
  if (scope === "clip") {
    c = await selectedClip();
    start = c.start;
    const key = crypto.createHash("md5").update([c.path, c.inPoint.toFixed(3), (c.end - c.start).toFixed(3), model, lang].join("|")).digest("hex").slice(0, 16);
    file = path.join(await outDir("Transcricao"), `${baseOf(c.name)}_${key}.json`);
  } else {
    const info = await seqInfo();
    memKey = [info.name, info.dur.toFixed(3), model, lang].join("|");
    file = path.join(os.tmpdir(), `pt_words_${Date.now()}.json`);
  }
  if (memKey && wordsMem[memKey]) raw = wordsMem[memKey];
  else if (!memKey && fs.existsSync(file)) raw = JSON.parse(fs.readFileSync(file, "utf8"));
  else {
    status("Extraindo o áudio…");
    const wav = c ? await clipWav(c, 16000, 1) : await seqWav();
    const srt = path.join(os.tmpdir(), `pt_words_${Date.now()}.srt`);
    status("Transcrevendo… (a primeira vez baixa o modelo)");
    progress(3);
    await run(BIN.python, [pyScript("transcrever.py"), wav, srt, model, lang, "linha", "32", "transcribe", file], (l) => {
      const p = l.match(/^PT (\d+)/);
      if (p) { progress(Number(p[1])); status(`Transcrevendo… ${p[1]}%`); }
    });
    fs.unlink(wav, () => {});
    fs.unlink(srt, () => {});
    raw = JSON.parse(fs.readFileSync(file, "utf8"));
    if (memKey) { wordsMem[memKey] = raw; fs.unlink(file, () => {}); }
  }
  if (!raw.length) throw new Error("Não achei fala nesse trecho.");
  return { clip: c, words: raw.map(([s, e, w]) => ({ s: start + s, e: start + e, w })) };
}

const normWord = (s) => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "");

// Para os vícios o acento conta: "é" não pode casar com "e"
const normExact = (s) => s.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");

// Onde a frase aparece: [{ i, n }] = índice da primeira palavra e quantas palavras.
// exact=false aceita pedaço de palavra ("escolh" acha "escolher").
function findPhrase(words, phrase, exact) {
  const nf = exact ? normExact : normWord;
  const want = phrase.split(/\s+/).map(nf).filter(Boolean), hits = [];
  if (!want.length) return hits;
  const norm = words.map((w) => nf(w.w));
  for (let i = 0; i + want.length <= norm.length; i++) {
    if (want.every((t, k) => (exact ? norm[i + k] === t : norm[i + k].includes(t)))) { hits.push({ i, n: want.length }); i += want.length - 1; }
  }
  return hits;
}

// Texto em volta do achado, com o achado entre <mark>
function contextHtml(words, hit, span) {
  const esc = (s) => s.replace(/[&<>]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[ch]));
  const a = Math.max(0, hit.i - span), b = Math.min(words.length, hit.i + hit.n + span);
  const txt = (x, y) => esc(words.slice(x, y).map((w) => w.w).join(" "));
  return (a > 0 ? "… " : "") + txt(a, hit.i) + " <mark>" + txt(hit.i, hit.i + hit.n) + "</mark> " + txt(hit.i + hit.n, b) + (b < words.length ? " …" : "");
}

// ---------- BUSCA PELA FALA ----------

function resetFala() {
  $("fa-out").innerHTML = "";
  $("fa-cut").classList.add("hidden");
  fill.picks = null;
}

async function searchSpeech() {
  const q = $("fa-q").value.trim();
  if (!q) throw new Error("Digite a palavra ou a frase.");
  resetFala();
  const { words } = await getWords($("fa-scope").value);
  const hits = findPhrase(words, q, false);
  hits.forEach((h) => {
    const el = document.createElement("div");
    el.className = "res go";
    el.innerHTML = `<div class="grow">${contextHtml(words, h, 5)}</div><b></b>`;
    el.lastChild.textContent = clock(words[h.i].s);
    el.addEventListener("click", () => jsx(`ft_goto(${Math.max(0, words[h.i].s - 0.3).toFixed(3)})`));
    $("fa-out").appendChild(el);
  });
  status(hits.length ? `"${q}" foi dito ${hits.length} ${hits.length === 1 ? "vez" : "vezes"}. Clique para ir até lá.` : `Não achei "${q}" na fala.`);
}
$("fa-find").addEventListener("click", () => guard($("fa-find"), searchSpeech));
$("fa-q").addEventListener("keydown", (e) => { if (e.key === "Enter") guard($("fa-find"), searchSpeech); });

// ---------- VÍCIOS DE FALA ----------

const fill = { clip: null, words: null, picks: null };

// Trechos a cortar (segundos da sequência, na grade de quadros): cada vício com uma folga
// pequena, sem invadir a palavra vizinha
function fillerRanges(words, hits, c) {
  const snap = (t) => Math.round(t / c.frame) * c.frame, out = [];
  hits.forEach((h) => {
    const first = words[h.i], last = words[h.i + h.n - 1], prev = words[h.i - 1], next = words[h.i + h.n];
    const s = Math.max(c.start, prev ? prev.e : c.start, first.s - 0.03), e = Math.min(c.end, next ? next.s : c.end, last.e + 0.03);
    const a = snap(s), b = snap(e), top = out[out.length - 1];
    if (b - a < c.frame * 2) return;
    if (top && a <= top[1]) top[1] = Math.max(top[1], b);
    else out.push([a, b]);
  });
  return out;
}

function updateFillBtn() {
  const n = fill.picks ? fill.picks.filter((p) => p.on).length : 0;
  $("fa-cut").textContent = `Cortar ${n} ${n === 1 ? "marcado" : "marcados"}`;
  $("fa-cut").classList.toggle("hidden", !n);
}

$("fa-scan").addEventListener("click", () => guard(null, async () => {
  resetFala();
  if ($("fa-scope").value !== "clip") throw new Error("Para cortar vícios, escolha \"Clipe selecionado\" e selecione o clipe da fala.");
  const list = $("fa-fillers").value.split(",").map((s) => s.trim()).filter(Boolean);
  if (!list.length) throw new Error("Escreva os vícios de fala, separados por vírgula.");
  saveConfig({ fillers: $("fa-fillers").value });
  const { words, clip } = await getWords("clip");
  let hits = [];
  list.forEach((f) => { hits = hits.concat(findPhrase(words, f, true)); });
  hits.sort((a, b) => a.i - b.i);
  hits = hits.filter((h, k) => !k || h.i >= hits[k - 1].i + hits[k - 1].n);
  if (!hits.length) { status("Não achei esses vícios na fala."); return; }
  fill.clip = clip;
  fill.words = words;
  fill.picks = hits.map((h) => ({ hit: h, on: true }));
  fill.picks.forEach((p) => {
    const el = document.createElement("label");
    el.className = "opt pick";
    el.innerHTML = `<input type="checkbox" checked><div class="grow">${contextHtml(words, p.hit, 4)}</div><small></small>`;
    el.lastChild.textContent = clock(words[p.hit.i].s);
    el.firstChild.addEventListener("change", (e) => { p.on = e.target.checked; updateFillBtn(); });
    $("fa-out").appendChild(el);
  });
  updateFillBtn();
  status(`Achei ${hits.length}. Desmarque os que fazem parte da frase e clique em cortar.`);
}));

$("fa-cut").addEventListener("click", () => guard($("fa-cut"), async () => {
  const c = fill.clip, ranges = fillerRanges(fill.words, fill.picks.filter((p) => p.on).map((p) => p.hit), c);
  if (!ranges.length) throw new Error("Os trechos marcados são curtos demais para cortar.");
  const csv = ranges.map(([a, b]) => a.toFixed(5) + "-" + b.toFixed(5)).join(";");
  status("Cortando…");
  const res = okRes(await jsx(`ft_cutSilences(${lit(csv)}, ${c.start}, ${c.end}, 1)`), "Cortar vícios").split(":");
  resetFala();
  status(`Pronto: ${ranges.length} vícios cortados em ${res[2]} trilhas (ficou uma cópia da sequência antes do corte)`);
}));

if (loadConfig().fillers) $("fa-fillers").value = loadConfig().fillers;
$("fa-scope").addEventListener("change", resetFala);

// ---------- SINCRONIZAR PELO SOM ----------

const SYNC_MAX = 900;      // analisa no máximo 15 min de cada clipe
const SYNC_MIN_CONF = 15;  // abaixo disso o pico da correlação não se destaca do ruído

$("cm-sync").addEventListener("click", () => guard($("cm-sync"), async () => {
  const sel = JSON.parse(await jsx("ft_selAudioWithTrack()"));
  if (sel.err) throw new Error(sel.err);
  // um clipe por trilha de áudio (estéreo solto em duas trilhas conta como dois; fica o de cima)
  const clips = sel.clips.sort((a, b) => a.track - b.track || a.start - b.start);
  if (clips.length < 2) throw new Error("Selecione pelo menos dois clipes com áudio: a câmera e o gravador.");
  const ref = clips[0], others = clips.slice(1).filter((c) => !(c.path === ref.path && Math.abs(c.start - ref.start) < 0.001));
  if (!others.length) throw new Error("Os clipes selecionados são o mesmo arquivo. Selecione a câmera e o gravador.");
  status("Extraindo o áudio…");
  progress(10);
  const wavs = [];
  for (const c of [ref].concat(others)) {
    const wav = path.join(os.tmpdir(), `pt_sync_${Date.now()}_${wavs.length}.wav`);
    await run(BIN.ffmpeg, ["-y", "-ss", String(c.inPoint), "-t", String(Math.min(SYNC_MAX, c.end - c.start)), "-i", c.path, "-vn", "-ac", "1", "-ar", "8000", wav]);
    wavs.push(wav);
  }
  status("Comparando o som…");
  progress(50);
  const lags = {};
  await run(BIN.python, [pyScript("sincronizar.py")].concat(wavs), (l) => {
    const m = l.match(/^LAG (\d+) (-?[\d.]+) (-?[\d.]+)/);
    if (m) lags[m[1]] = { lag: parseFloat(m[2]), conf: parseFloat(m[3]) };
  });
  wavs.forEach((w) => fs.unlink(w, () => {}));
  let moved = 0;
  const fails = [];
  for (let i = 0; i < others.length; i++) {
    const c = others[i], r = lags[i];
    if (!r || r.conf < SYNC_MIN_CONF) { fails.push(c.name); continue; }
    // o mesmo som está `lag` segundos mais tarde no outro clipe: ele precisa começar `lag` antes da referência
    const delta = ref.start - r.lag - c.start;
    if (Math.abs(c.start - ref.start) < 0.001 && Math.abs(c.end - ref.end) < 0.001 && Math.abs(delta) > 0.0005) {
      throw new Error("Os dois clipes começam e terminam no mesmo ponto, e eu não consigo mover um sem o outro. Arraste um deles um pouco para o lado e tente de novo.");
    }
    if (c.start + delta < -0.001) throw new Error(`"${c.name}" começa antes do início da sequência. Arraste os clipes para a frente na timeline e tente de novo.`);
    if (Math.abs(delta) > 0.0005) okRes(await jsx(`ft_moveBlock(${c.start}, ${c.end}, ${delta.toFixed(5)})`), "Sincronizar");
    moved++;
  }
  if (!moved) throw new Error("Não achei som em comum entre os clipes. Eles gravaram o mesmo momento?");
  status(`Pronto: ${moved} ${moved === 1 ? "clipe sincronizado" : "clipes sincronizados"} com "${ref.name}"` + (fails.length ? `; sem som em comum: ${fails.join(", ")}` : ""));
}));

// ---------- CORTE POR QUEM FALA ----------

const CAM_WIN = 0.1; // janela de medição do volume, em segundos

function pcm8k(file, ss, t) {
  return new Promise((resolve, reject) => {
    const p = cp.spawn(BIN.ffmpeg, ["-v", "error", "-ss", String(ss), "-t", String(t), "-i", file, "-vn", "-ac", "1", "-ar", "8000", "-f", "s16le", "-"]);
    const chunks = [];
    p.stdout.on("data", (d) => chunks.push(d));
    p.on("error", reject);
    p.on("close", () => resolve(Buffer.concat(chunks)));
  });
}

// Volume (dB) de uma trilha de áudio em janelas de CAM_WIN, de S a E na sequência
async function trackEnvelope(idx, S, E) {
  const data = JSON.parse(await jsx(`ft_trackClips(${idx})`));
  if (data.err) throw new Error(data.err);
  const env = new Float32Array(Math.ceil((E - S) / CAM_WIN)).fill(-100), win = 8000 * CAM_WIN;
  for (const c of data.clips) {
    const a = Math.max(c.start, S), b = Math.min(c.end, E);
    if (b - a < CAM_WIN) continue;
    const buf = await pcm8k(c.path, c.inPoint + (a - c.start), b - a), first = Math.round((a - S) / CAM_WIN);
    for (let k = 0; (k + 1) * win * 2 <= buf.length && first + k < env.length; k++) {
      let sum = 0;
      for (let i = 0; i < win; i++) { const v = buf.readInt16LE((k * win + i) * 2) / 32768; sum += v * v; }
      env[first + k] = 10 * Math.log10(sum / win + 1e-12);
    }
  }
  return env;
}

// Quem está falando em cada momento: [[inicio, fim, "up"|"down"]] em segundos a partir de S.
// Troca só quando uma voz passa a outra por 4 dB, e nenhum plano fica menor que minLen.
function whoSpeaks(up, down, minLen) {
  const n = Math.min(up.length, down.length), raw = [];
  let state = null;
  for (let i = 0; i < n; i++) {
    if (up[i] > -50 || down[i] > -50) {
      if (up[i] > down[i] + 4) state = "up";
      else if (down[i] > up[i] + 4) state = "down";
    }
    raw.push(state);
  }
  const firstKnown = raw.find((s) => s) || "down";
  const segs = [];
  raw.forEach((s, i) => {
    const who = s || firstKnown, last = segs[segs.length - 1];
    if (last && last[2] === who) last[1] = i + 1;
    else segs.push([i, i + 1, who]);
  });
  const minWin = minLen / CAM_WIN, out = [];
  segs.forEach((seg) => {
    const last = out[out.length - 1];
    if (last && (last[2] === seg[2] || seg[1] - seg[0] < minWin)) last[1] = seg[1];
    else out.push(seg.slice());
  });
  if (out.length > 1 && out[0][1] - out[0][0] < minWin) { out[1][0] = out[0][0]; out.shift(); }
  // junta vizinhos iguais que sobraram depois de absorver planos curtos
  const merged = [];
  out.forEach((seg) => {
    const last = merged[merged.length - 1];
    if (last && last[2] === seg[2]) last[1] = seg[1];
    else merged.push(seg);
  });
  return merged.map(([a, b, who]) => [a * CAM_WIN, b * CAM_WIN, who]);
}

async function fillCamTracks() {
  try {
    const data = JSON.parse(await jsx("ft_audioTracks()"));
    if (data.err) return;
    ["cm-up", "cm-down"].forEach((id, k) => {
      const sel = $(id), keep = sel.value;
      sel.innerHTML = "";
      data.tracks.forEach((t) => { const o = document.createElement("option"); o.value = t.i; o.textContent = `A${t.i + 1} (${t.n} ${t.n === 1 ? "clipe" : "clipes"})`; sel.appendChild(o); });
      sel.value = data.tracks.some((t) => String(t.i) === keep) ? keep : String(Math.min(k, data.tracks.length - 1));
    });
  } catch (e) {}
}
document.querySelector('.segb[data-mode="cam"]').addEventListener("click", fillCamTracks);
$("cm-min").addEventListener("input", () => { $("cm-min-v").textContent = num($("cm-min").value, 1) + " s"; });

$("cm-cut").addEventListener("click", () => guard($("cm-cut"), async () => {
  const v = JSON.parse(await jsx("ft_selectedVideo()"));
  if (v.err) throw new Error(v.err);
  if (v.track === 0) throw new Error("O clipe selecionado está na V1. Selecione a câmera que está em cima da outra.");
  const upIdx = Number($("cm-up").value), downIdx = Number($("cm-down").value);
  if (upIdx === downIdx) throw new Error("Escolha trilhas diferentes para as duas vozes.");
  status("Ouvindo as duas vozes…");
  progress(20);
  const up = await trackEnvelope(upIdx, v.start, v.end);
  progress(55);
  const down = await trackEnvelope(downIdx, v.start, v.end);
  if (!up.some((x) => x > -50) || !down.some((x) => x > -50)) throw new Error("Uma das trilhas de voz está vazia ou em silêncio nesse trecho.");
  const segs = whoSpeaks(up, down, Number($("cm-min").value));
  const snap = (t) => Math.round(t / v.frame) * v.frame;
  // a troca entra um pouco antes da fala, para não pegar a pessoa já falando
  const hide = segs.filter((s) => s[2] === "down").map(([a, b]) => [snap(Math.max(v.start, v.start + a - 0.2)), snap(Math.min(v.end, v.start + b - 0.2 * (v.start + b < v.end - 0.05 ? 1 : 0)))]);
  if (!hide.length) throw new Error("Só a pessoa da câmera de cima fala nesse trecho. Não há o que cortar.");
  progress(85);
  const res = okRes(await jsx(`ft_camCut(${v.track}, ${v.start}, ${v.end}, ${lit(hide.map(([a, b]) => a.toFixed(5) + "-" + b.toFixed(5)).join(";"))})`), "Corte por quem fala").split(":");
  status(`Pronto: ${res[1]} planos, a câmera de cima aparece em ${Number(res[1]) - Number(res[2])}`);
}));

$("cm-undo").addEventListener("click", () => guard(null, async () => {
  const v = JSON.parse(await jsx("ft_selectedVideo()"));
  if (v.err) throw new Error("Selecione um pedaço da câmera de cima.");
  const res = okRes(await jsx(`ft_camCut(${v.track}, 0, 1e9, "")`), "Câmeras").split(":");
  status(`Câmera de cima visível de novo em ${res[1]} pedaços (os cortes continuam lá)`);
}));

// ---------- ORTOGRAFIA DA LEGENDA ----------

// Usa o corretor do próprio macOS. Devolve as palavras que ele não conhece.
async function misspelled(wordsList, lang) {
  const file = path.join(os.tmpdir(), `pt_spell_${Date.now()}.txt`);
  fs.writeFileSync(file, wordsList.join("\n"));
  const script = `ObjC.import("AppKit");
    function run(argv) {
      var sc = $.NSSpellChecker.sharedSpellChecker; sc.setLanguage(argv[1]);
      var txt = $.NSString.stringWithContentsOfFileEncodingError(argv[0], $.NSUTF8StringEncoding, null).js.split("\\n"), bad = [];
      for (var i = 0; i < txt.length; i++) { if (txt[i] && sc.checkSpellingOfStringStartingAt(txt[i], 0).length > 0) bad.push(txt[i]); }
      return bad.join("\\n");
    }`;
  const out = await run("/usr/bin/osascript", ["-l", "JavaScript", "-e", script, file, lang]);
  fs.unlink(file, () => {});
  return out.split("\n").map((s) => s.trim()).filter(Boolean);
}

// Palavras de uma legenda, sem pontuação nas pontas; números ficam de fora
const cueWords = (text) => text.split(/\s+/).map((w) => w.replace(/^[^\p{L}]+|[^\p{L}]+$/gu, "")).filter((w) => w.length > 1 && !/\d/.test(w));

$("ck-spell").addEventListener("click", () => guard(null, async () => {
  const srt = pickFile("Escolha o SRT da legenda", ["srt"]);
  if (!srt) return;
  const cues = parseSrt(fs.readFileSync(srt, "utf8"));
  if (!cues.length) throw new Error("Esse SRT não tem legendas.");
  $("ck-out").innerHTML = "";
  status("Conferindo a ortografia…");
  const lang = /_en(_|\.)/i.test(path.basename(srt)) ? "en" : "pt_BR";
  const all = Array.from(new Set(cues.flatMap((c) => cueWords(c.text))));
  const bad = new Set(await misspelled(all, lang));
  let meta = { start: 0 };
  try { meta = JSON.parse(fs.readFileSync(srt + ".json", "utf8")); } catch (e) {}
  let n = 0;
  cues.forEach((c) => {
    const wrong = cueWords(c.text).filter((w) => bad.has(w));
    if (!wrong.length) return;
    n += wrong.length;
    checkRow("bad", `${wrong.join(", ")} — em "${c.text.replace(/\n/g, " ")}"`, clock(meta.start + c.start), meta.start + c.start);
  });
  if (!n) checkRow("fine", `${cues.length} legendas sem erro de ortografia`, "ok", null);
  status(n ? `${n} ${n === 1 ? "palavra" : "palavras"} para conferir (nomes próprios também aparecem aqui)` : "Nenhum erro de ortografia na legenda.");
}));
