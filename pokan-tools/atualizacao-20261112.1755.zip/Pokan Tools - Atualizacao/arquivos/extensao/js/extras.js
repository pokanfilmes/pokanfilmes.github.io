// Pokan Tools — limpar ruído, volume, legendas, silêncios, batidas e exportação
// Usa os utilitários de main.js (run, jsx, guard, status, progress, outDir, selectedClip…)

const EXT_DIR = path.dirname(decodeURI(window.location.pathname));
const pyScript = (name) => path.join(EXT_DIR, "py", name);

function amePresets() {
  const apps = fs.readdirSync("/Applications").filter((d) => /^Adobe Media Encoder/.test(d)).sort();
  if (!apps.length) throw new Error("Não achei o Adobe Media Encoder instalado.");
  const app = apps[apps.length - 1];
  return path.join("/Applications", app, app + ".app/Contents/MediaIO/systempresets");
}
const WAV_PRESET = "3F3F3F3F_57415645/Waveform Audio 48kHz 16-bit.epr";

const stampNow = () => new Date().toTimeString().slice(0, 8).replace(/:/g, "");
const num = (v, d) => Number(v).toFixed(d).replace(".", ",");
const baseOf = (name) => safeName(path.basename(name, path.extname(name)));

function okRes(res, what) {
  if (!res || /^ERR|EvalScript error/.test(res)) throw new Error(what + ": " + String(res).replace(/^ERR:/, ""));
  return res;
}

async function seqInfo() {
  const info = JSON.parse(await jsx("ft_seqInfo()"));
  if (info.err) throw new Error(info.err);
  return info;
}

// Trecho do clipe que está na timeline, em WAV temporário
async function clipWav(c, rate, channels) {
  const wav = path.join(os.tmpdir(), `pt_${Date.now()}.wav`);
  await run(BIN.ffmpeg, ["-y", "-ss", String(c.inPoint), "-t", String(c.end - c.start), "-i", c.path,
    "-vn", "-ac", String(channels), "-ar", String(rate), wav]);
  return wav;
}

// Mixagem da sequência inteira em WAV temporário (o Premiere fica ocupado enquanto exporta)
async function seqWav() {
  const wav = path.join(os.tmpdir(), `pt_seq_${Date.now()}.wav`);
  status("Exportando o áudio da sequência… (o Premiere fica ocupado)");
  okRes(await jsx(`ft_exportDirect(${lit(wav)}, ${lit(path.join(amePresets(), WAV_PRESET))})`), "Exportar áudio");
  if (!fs.existsSync(wav)) throw new Error("O Premiere não gerou o áudio da sequência.");
  return wav;
}

// ---------- LIMPAR RUÍDO ----------

// Piso de ruído do trecho em dBFS: o décimo percentil do RMS em janelas de 100 ms.
// O afftdn só reduz de verdade quando recebe um piso coerente com o chiado do clipe.
function noiseFloor(c) {
  return new Promise((resolve, reject) => {
    const p = cp.spawn(BIN.ffmpeg, ["-v", "error", "-ss", String(c.inPoint), "-t", String(Math.min(300, c.end - c.start)), "-i", c.path,
      "-vn", "-ac", "1", "-ar", "8000", "-f", "s16le", "-"]);
    const chunks = [];
    p.stdout.on("data", (d) => chunks.push(d));
    p.on("error", reject);
    p.on("close", () => {
      const buf = Buffer.concat(chunks), win = 800, levels = [];
      for (let o = 0; o + win * 2 <= buf.length; o += win * 2) {
        let sum = 0;
        for (let i = 0; i < win; i++) { const v = buf.readInt16LE(o + i * 2) / 32768; sum += v * v; }
        levels.push(10 * Math.log10(sum / win + 1e-12));
      }
      if (!levels.length) return resolve(-50);
      levels.sort((a, b) => a - b);
      resolve(levels[Math.floor(levels.length * 0.1)]);
    });
  });
}
const denoiseFilter = (floor, strength) => `afftdn=nr=${strength}:nf=${Math.round(Math.max(-80, Math.min(-20, floor + 20)))}`;

$("cl-go").addEventListener("click", () => guard($("cl-go"), async () => {
  const c = await selectedClip();
  const dir = await outDir("Audio");
  const out = path.join(dir, `${baseOf(c.name)}_limpo_${stampNow()}.wav`);
  const filters = [];
  if ($("cl-hp").checked) filters.push("highpass=f=80");
  status("Medindo o chiado…");
  progress(15);
  filters.push(denoiseFilter(await noiseFloor(c), $("cl-strength").value));
  status("Limpando o ruído…");
  progress(40);
  await run(BIN.ffmpeg, ["-y", "-ss", String(c.inPoint), "-t", String(c.end - c.start), "-i", c.path,
    "-vn", "-ac", "2", "-ar", "48000", "-af", filters.join(","), "-c:a", "pcm_s24le", out]);
  progress(80);
  const res = await importToPremiere(out, "Pokan Tools/Audio", String(c.start), "audio");
  if ($("cl-mute").checked) await jsx(`ft_disableClip(${lit(c.nodeId)})`);
  status(`Pronto: versão limpa na trilha ${res.replace("OK:", "")}`);
}));

// ---------- VOLUME (LUFS) ----------

async function measure(file) {
  const lines = [];
  await run(BIN.ffmpeg, ["-hide_banner", "-nostats", "-i", file, "-af", "loudnorm=I=-14:TP=-1:print_format=json", "-f", "null", "-"], (l) => lines.push(l));
  const m = lines.join("\n").match(/\{[^{}]*"input_i"[^{}]*\}/);
  if (!m) throw new Error("Não consegui medir o volume.");
  const j = JSON.parse(m[0]);
  return { i: parseFloat(j.input_i), tp: parseFloat(j.input_tp) };
}

// Ganho para chegar ao alvo sem deixar o pico passar de -1 dB
function gainFor(m, target) {
  if (!isFinite(m.i)) return null;
  const want = target - m.i, max = -1 - m.tp;
  return { db: Math.min(want, max), capped: want > max };
}

function luRow(name, text) {
  const el = document.createElement("div");
  el.className = "res";
  el.innerHTML = `<div class="grow"></div><b></b>`;
  el.firstChild.textContent = name;
  el.lastChild.textContent = text;
  $("lu-out").appendChild(el);
}
const signed = (db) => (db >= 0 ? "+" : "−") + num(Math.abs(db), 1) + " dB";

$("lu-go").addEventListener("click", () => guard($("lu-go"), async () => {
  const target = Number($("lu-target").value);
  $("lu-out").innerHTML = "";

  if ($("lu-scope").value === "seq") {
    const wav = await seqWav();
    status("Medindo o volume…");
    progress(60);
    const m = await measure(wav);
    fs.unlink(wav, () => {});
    const g = gainFor(m, target);
    if (!g) throw new Error("A sequência está em silêncio.");
    const res = okRes(await jsx(`ft_gainAll(${g.db.toFixed(2)})`), "Ajustar volume").split(":");
    luRow("Sequência", `${num(m.i, 1)} LUFS → ${signed(g.db)}`);
    status(`Pronto: ${signed(g.db)} em ${res[1]} clipes` + (g.capped ? " (limitado pelo pico)" : "") + (res[2] !== "0" ? `, ${res[2]} com keyframes ficaram de fora` : ""));
    return;
  }

  const sel = JSON.parse(await jsx("ft_selectedAudioClips()"));
  if (sel.err) throw new Error(sel.err);
  let done = 0;
  for (const c of sel.clips) {
    status(`Medindo ${done + 1}/${sel.clips.length}…`);
    progress((done / sel.clips.length) * 100);
    const wav = await clipWav(c, 48000, 2);
    const m = await measure(wav);
    fs.unlink(wav, () => {});
    const g = gainFor(m, target);
    if (!g) luRow(c.name, "silêncio");
    else {
      const res = okRes(await jsx(`ft_addGain(${lit(c.nodeId)}, ${g.db.toFixed(2)})`), "Ajustar volume");
      luRow(c.name, res === "OK:KEY" ? "tem keyframes" : `${num(m.i, 1)} → ${signed(g.db)}${g.capped ? " (pico)" : ""}`);
    }
    done++;
  }
  status(`Pronto: ${done} clipes medidos para ${target} LUFS`);
}));

// ---------- LEGENDAS ----------
// O Premiere não deixa uma extensão mudar o estilo da trilha de legenda. Por isso a legenda
// "com estilo" é desenhada aqui (ASS + ffmpeg) num vídeo transparente que vai por cima de tudo.

const CAP_COLORS = {
  white: { css: "#FFFFFF", ass: "&H00FFFFFF", edgeCss: "#000000", edgeAss: "&H00000000" },
  orange: { css: "#FF5A02", ass: "&H00025AFF", edgeCss: "#000000", edgeAss: "&H00000000" },
  yellow: { css: "#FFD400", ass: "&H0000D4FF", edgeCss: "#000000", edgeAss: "&H00000000" },
  black: { css: "#000000", ass: "&H00000000", edgeCss: "#FFFFFF", edgeAss: "&H00FFFFFF" },
};
const CAP_OUTLINE = 0.07; // espessura do contorno, em fração do tamanho da letra

function capStyle() {
  return {
    font: $("cp-font").value, size: Number($("cp-size").value), pos: Number($("cp-pos").value),
    color: $("cp-color").value, outline: $("cp-outline").checked, upper: $("cp-upper").checked,
  };
}

function updateCapPreview() {
  const st = capStyle(), col = CAP_COLORS[st.color], t = $("cp-prev-t");
  $("cp-styled").classList.toggle("hidden", $("cp-kind").value !== "styled");
  $("cp-size-v").textContent = num(st.size, 1) + "%";
  $("cp-pos-v").textContent = st.pos + "% (" + (st.pos < 35 ? "em cima" : st.pos > 65 ? "embaixo" : "no meio") + ")";
  const px = $("cp-prev").clientHeight * st.size / 100, e = Math.max(0.5, px * CAP_OUTLINE);
  t.style.fontFamily = JSON.stringify(st.font);
  t.style.fontSize = px + "px";
  t.style.top = st.pos + "%";
  t.style.color = col.css;
  t.style.textTransform = st.upper ? "uppercase" : "none";
  t.style.textShadow = !st.outline ? "none"
    : [[-1, -1], [0, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [0, 1], [1, 1]].map(([x, y]) => `${x * e}px ${y * e}px 0 ${col.edgeCss}`).join(",");
}

["cp-kind", "cp-font", "cp-size", "cp-pos", "cp-color", "cp-outline", "cp-upper"].forEach((id) => {
  $(id).addEventListener("input", () => {
    updateCapPreview();
    saveConfig({ cap: Object.assign(capStyle(), { kind: $("cp-kind").value }) });
  });
});

// A prévia acompanha o formato da sequência aberta
document.querySelector('.tab[data-tab="edit"]').addEventListener("click", async () => {
  try { const i = await seqInfo(); $("cp-prev").style.aspectRatio = i.width + " / " + i.height; } catch (e) {}
  updateCapPreview();
});

(function initCaptions() {
  const saved = loadConfig().cap || {};
  if (saved.kind) $("cp-kind").value = saved.kind;
  if (saved.size) $("cp-size").value = saved.size;
  if (saved.pos) $("cp-pos").value = saved.pos;
  if (saved.color) $("cp-color").value = saved.color;
  if (saved.outline != null) $("cp-outline").checked = saved.outline;
  if (saved.upper != null) $("cp-upper").checked = saved.upper;
  // famílias de fonte que o macOS enxerga (as mesmas que o desenho da legenda usa)
  const script = 'ObjC.import("AppKit"); $.NSFontManager.sharedFontManager.availableFontFamilies.js.map(function(x){return x.js}).join("\\n")';
  cp.execFile("/usr/bin/osascript", ["-l", "JavaScript", "-e", script], (err, out) => {
    let fams = err ? [] : out.split("\n").map((s) => s.trim()).filter((s) => s && s[0] !== ".");
    if (!fams.length) fams = ["Helvetica Neue", "Arial", "Impact"];
    const sel = $("cp-font");
    sel.innerHTML = "";
    fams.forEach((f) => { const o = document.createElement("option"); o.textContent = f; sel.appendChild(o); });
    const pick = [saved.font, "Outfit", "Poppins", "Helvetica Neue"].find((f) => f && fams.includes(f));
    if (pick) sel.value = pick;
    $("br-font").innerHTML = sel.innerHTML;
    $("br-font").value = (loadConfig().bar || {}).font || sel.value;
    updateCapPreview();
  });
  updateCapPreview();
})();

function parseSrt(text) {
  return text.replace(/\r/g, "").split(/\n\n+/).map((block) => {
    const m = block.match(/(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)\n([\s\S]+)/);
    if (!m) return null;
    const at = (i) => Number(m[i]) * 3600 + Number(m[i + 1]) * 60 + Number(m[i + 2]) + Number(m[i + 3]) / 1000;
    return { start: at(1), end: at(5), text: m[9].trim() };
  }).filter(Boolean);
}

function assTime(t) {
  const cs = Math.round(t * 100), p = (n) => String(n).padStart(2, "0");
  return `${Math.floor(cs / 360000)}:${p(Math.floor(cs / 6000) % 60)}:${p(Math.floor(cs / 100) % 60)}.${p(cs % 100)}`;
}

function buildAss(cues, st, W, H) {
  const col = CAP_COLORS[st.color], size = Math.round(H * st.size / 100);
  const outline = st.outline ? (size * CAP_OUTLINE).toFixed(1) : "0";
  const margin = Math.round(W * 0.06), x = Math.round(W / 2), y = Math.round(H * st.pos / 100);
  const lines = cues.map((c) => {
    let text = c.text.replace(/[{}]/g, "").replace(/\n/g, "\\N");
    if (st.upper) text = text.toUpperCase().replace(/\\n/g, "\\N");
    return `Dialogue: 0,${assTime(c.start)},${assTime(c.end)},P,,0,0,0,,{\\an5\\pos(${x},${y})}${text}`;
  });
  return `[Script Info]
ScriptType: v4.00+
PlayResX: ${W}
PlayResY: ${H}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: P,${st.font.replace(/,/g, "")},${size},${col.ass},${col.ass},${col.edgeAss},&H00000000,0,0,0,0,100,100,0,0,1,${outline},0,5,${margin},${margin},0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
${lines.join("\n")}
`;
}

function fpsArg(frame) {
  const fps = 1 / frame;
  const ntsc = [[23.976, "24000/1001"], [29.97, "30000/1001"], [59.94, "60000/1001"]].find(([f]) => Math.abs(fps - f) < 0.01);
  return ntsc ? ntsc[1] : String(Math.round(fps * 1000) / 1000);
}

// Desenha as legendas num .mov ProRes 4444 transparente, do tamanho da sequência
async function renderCaptions(cues, st, info, dur, out) {
  const ass = path.join(os.tmpdir(), `pt_cap_${Date.now()}.ass`);
  if (/[:',;\[\]\\ ]/.test(ass)) throw new Error("A pasta temporária tem caracteres que o ffmpeg não aceita.");
  fs.writeFileSync(ass, buildAss(cues, st, info.width, info.height));
  await run(BIN.ffmpeg, ["-y", "-f", "lavfi", "-i", `color=c=black@0.0:s=${info.width}x${info.height}:r=${fpsArg(info.frame)}:d=${dur.toFixed(3)},format=rgba`,
    "-vf", `subtitles=${ass}:alpha=1`, "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le", "-q:v", "20",
    "-progress", "pipe:1", "-nostats", out], (l) => {
    const m = l.match(/^out_time_ms=(\d+)/);
    if (m) { const pct = Math.min(100, (Number(m[1]) / 1e6 / dur) * 100); progress(pct); status(`Desenhando as legendas… ${Math.round(pct)}%`); }
  });
  fs.unlink(ass, () => {});
}

async function placeStyled(srt, start, dur) {
  const info = await seqInfo();
  const cues = parseSrt(fs.readFileSync(srt, "utf8"));
  if (!cues.length) throw new Error("Esse SRT não tem legendas.");
  const mov = srt.replace(/\.srt$/i, "") + `_estilo_${stampNow()}.mov`;
  status("Desenhando as legendas…");
  await renderCaptions(cues, capStyle(), info, dur, mov);
  const res = okRes(await jsx(`ft_importTop(${lit(mov)}, "Pokan Tools/Legendas", ${start}, ${dur})`), "Legendas");
  status(`Pronto: ${cues.length} legendas na trilha ${res.replace("OK:", "")}`);
}

$("cp-go").addEventListener("click", () => guard($("cp-go"), async () => {
  let wav, start, dur, name;
  if ($("cp-scope").value === "clip") {
    const c = await selectedClip();
    status("Extraindo o áudio…");
    wav = await clipWav(c, 16000, 1);
    start = c.start;
    dur = c.end - c.start;
    name = c.name;
  } else {
    const info = await seqInfo();
    name = info.name;
    dur = info.dur;
    wav = await seqWav();
    start = 0;
  }
  const dir = await outDir("Legendas");
  const task = $("cp-task").value; // "translate" = o Whisper já escreve a legenda em inglês
  const srt = path.join(dir, `${baseOf(name)}_${task === "translate" ? "en_" : ""}${stampNow()}.srt`);
  const [mode, size] = $("cp-style").value.split(":");

  status((task === "translate" ? "Transcrevendo e traduzindo…" : "Transcrevendo…") + " (a primeira vez baixa o modelo)");
  progress(3);
  let count = 0;
  await run(BIN.python, [pyScript("transcrever.py"), wav, srt, $("cp-model").value, $("cp-lang").value, mode, size, task], (l) => {
    const p = l.match(/^PT (\d+)/), ok = l.match(/^OK (\d+)/);
    if (p) { progress(Number(p[1])); status(`Transcrevendo… ${p[1]}%`); }
    if (ok) count = Number(ok[1]);
  });
  fs.unlink(wav, () => {});
  if (!count) throw new Error("Não achei fala nesse trecho.");
  // guarda onde a legenda começa, para poder trocar o estilo depois sem transcrever de novo
  fs.writeFileSync(srt + ".json", JSON.stringify({ start, dur }));

  if ($("cp-kind").value === "styled") return placeStyled(srt, start, dur);
  const res = await jsx(`ft_addCaptions(${lit(srt)}, ${start}, "Pokan Tools/Legendas")`);
  if (res === "OK") status(`Pronto: ${count} legendas na timeline`);
  else {
    log("legendas: " + res);
    okRes(res, "Legendas");
    status(`${count} legendas no bin Pokan Tools/Legendas — arraste o arquivo para a timeline.`);
  }
}));

$("cp-restyle").addEventListener("click", () => guard($("cp-restyle"), async () => {
  const srt = pickFile("Escolha o SRT da legenda", ["srt"]);
  if (!srt) return;
  let meta;
  try { meta = JSON.parse(fs.readFileSync(srt + ".json", "utf8")); } catch (e) {
    const cues = parseSrt(fs.readFileSync(srt, "utf8"));
    meta = { start: 0, dur: cues.length ? cues[cues.length - 1].end + 0.5 : 1 };
  }
  lastDir = path.dirname(srt);
  await placeStyled(srt, meta.start, meta.dur);
}));

// ---------- SILÊNCIOS ----------

const sil = { clip: null, ranges: null };

function resetSil() {
  sil.clip = sil.ranges = null;
  $("si-cut").classList.add("hidden");
}
[["si-db", (v) => v + " dB"], ["si-min", (v) => num(v, 1) + " s"], ["si-pad", (v) => num(v, 2) + " s"]].forEach(([id, fmt]) => {
  $(id).addEventListener("input", () => { $(id + "-v").textContent = fmt($(id).value); resetSil(); });
});

// Linhas do silencedetect -> trechos a remover, em segundos da sequência, na grade de quadros
function silenceRanges(lines, c, pad) {
  const dur = c.end - c.start, raw = [];
  let open = null;
  lines.forEach((l) => {
    const s = l.match(/silence_start: (-?[\d.]+)/), e = l.match(/silence_end: ([\d.]+)/);
    if (s) open = Math.max(0, parseFloat(s[1]));
    if (e && open != null) { raw.push([open, Math.min(dur, parseFloat(e[1]))]); open = null; }
  });
  if (open != null) raw.push([open, dur]);
  const snap = (t) => Math.round((c.start + t) / c.frame) * c.frame;
  return raw.map(([s, e]) => [
    s <= 0.02 ? c.start : snap(s + pad),          // silêncio na ponta do clipe sai inteiro
    e >= dur - 0.02 ? c.end : snap(e - pad),
  ]).filter(([a, b]) => b - a >= c.frame * 2);
}

$("si-scan").addEventListener("click", () => guard($("si-scan"), async () => {
  resetSil();
  const c = await selectedClip();
  status("Procurando pausas…");
  progress(40);
  const lines = [];
  await run(BIN.ffmpeg, ["-hide_banner", "-nostats", "-ss", String(c.inPoint), "-t", String(c.end - c.start), "-i", c.path, "-vn",
    "-af", `silencedetect=noise=${$("si-db").value}dB:d=${$("si-min").value}`, "-f", "null", "-"], (l) => lines.push(l));
  const ranges = silenceRanges(lines, c, Number($("si-pad").value));
  if (!ranges.length) { status("Nenhuma pausa com esses ajustes."); return; }
  const total = ranges.reduce((t, [a, b]) => t + (b - a), 0);
  sil.clip = c;
  sil.ranges = ranges;
  $("si-cut").textContent = `Cortar ${ranges.length} pausas (${num(total, 1)} s a menos)`;
  $("si-cut").classList.remove("hidden");
  status(`Achei ${ranges.length} pausas, ${num(total, 1)} s no total.`);
}));

$("si-cut").addEventListener("click", () => guard($("si-cut"), async () => {
  const c = sil.clip, ranges = sil.ranges;
  if (!c || !ranges) throw new Error("Procure as pausas primeiro.");
  const csv = ranges.map(([a, b]) => a.toFixed(5) + "-" + b.toFixed(5)).join(";");
  status("Cortando…");
  const res = okRes(await jsx(`ft_cutSilences(${lit(csv)}, ${c.start}, ${c.end}, ${$("si-bak").checked ? 1 : 0})`), "Cortar pausas").split(":");
  resetSil();
  status(`Pronto: ${ranges.length} pausas cortadas em ${res[2]} trilhas`);
}));

// ---------- BATIDAS ----------

const BEAT_MARKER = "Batida";

$("bt-go").addEventListener("click", () => guard($("bt-go"), async () => {
  const c = await selectedClip();
  status("Analisando a música…");
  progress(20);
  const wav = await clipWav(c, 22050, 1);
  let data = null;
  await run(BIN.python, [pyScript("batidas.py"), wav], (l) => {
    if (l.indexOf("BEATS ") === 0) data = JSON.parse(l.slice(6));
  });
  fs.unlink(wav, () => {});
  if (!data || !data.beats.length) throw new Error("Não achei batida nesse clipe.");
  const every = Number($("bt-every").value);
  const times = data.beats.filter((_, i) => i % every === 0).map((t) => (c.start + t).toFixed(3));
  progress(80);
  const res = okRes(await jsx(`ft_addMarkers(${lit(times.join(","))}, ${lit(BEAT_MARKER)})`), "Marcadores");
  status(`Pronto: ${res.split(":")[1]} marcadores · ${num(data.bpm, 0)} BPM`);
}));

$("bt-clear").addEventListener("click", () => guard($("bt-clear"), async () => {
  const res = okRes(await jsx(`ft_clearMarkers(${lit(BEAT_MARKER)})`), "Marcadores");
  status(`${res.split(":")[1]} marcadores de batida apagados`);
}));

// ---------- EXPORTAR ----------

const EXPORTS = {
  alta: { preset: "4E49434B_48323634/01 - Match Source - High bitrate.epr", ext: "mp4", tag: "Alta" },
  media: { preset: "4E49434B_48323634/01 - Match Source - Medium bitrate.epr", ext: "mp4", tag: "Media" },
  leve: { preset: "4E49434B_48323634/02 - Match Source - Low bitrate.epr", ext: "mp4", tag: "Leve" },
  wav: { preset: WAV_PRESET, ext: "wav", tag: "Audio" },
};

$("ex-go").addEventListener("click", () => guard($("ex-go"), async () => {
  const picks = Array.from(document.querySelectorAll(".ex-v:checked")).map((el) => EXPORTS[el.value]);
  if (!picks.length) throw new Error("Marque pelo menos uma versão.");
  const info = await seqInfo();
  const presets = amePresets();
  picks.forEach((p) => { if (!fs.existsSync(path.join(presets, p.preset))) throw new Error("Preset não encontrado: " + path.basename(p.preset)); });
  const dir = await outDir("Exports");
  status("Abrindo o Media Encoder…");
  okRes(await jsx("ft_launchAME()"), "Media Encoder");
  for (const p of picks) {
    const out = path.join(dir, `${safeName(info.name)}_${p.tag}.${p.ext}`);
    okRes(await jsx(`ft_queue(${lit(out)}, ${lit(path.join(presets, p.preset))}, ${lit($("ex-range").value)})`), "Fila");
  }
  if ($("ex-start").checked) okRes(await jsx("ft_startBatch()"), "Fila");
  status(`Pronto: ${picks.length} versões na fila do Media Encoder`);
}));

// ---------- MARCAR (decupagem) ----------

// Cores de marcador do Premiere, na ordem do índice que o setColorByIndex espera
const MARKER_COLORS = ["#4CAF50", "#E5534B", "#9B6DD6", "#FF8A3D", "#F2C94C", "#F2EFEA", "#4A90E2", "#3CC8D8"];
const DEFAULT_TAGS = [
  { name: "Imagem fechada", color: 6 }, { name: "Imagem aberta", color: 0 }, { name: "Detalhe", color: 4 },
  { name: "Entrevista", color: 2 }, { name: "B-roll", color: 7 }, { name: "Melhor take", color: 3 }, { name: "Descartar", color: 1 },
];
const getTags = () => loadConfig().tags || DEFAULT_TAGS;
const tagNames = () => getTags().map((t) => t.name).join("|");

function renderTags() {
  const box = $("mk-tags");
  box.innerHTML = "";
  getTags().forEach((tag) => {
    const b = document.createElement("button");
    b.className = "tagb";
    b.innerHTML = "<i></i><span></span>";
    b.firstChild.style.background = MARKER_COLORS[tag.color];
    b.lastChild.textContent = tag.name;
    b.addEventListener("click", () => {
      if (box.classList.contains("editing")) {
        saveConfig({ tags: getTags().filter((t) => t.name !== tag.name) });
        renderTags();
        return;
      }
      guard(null, async () => {
        const res = okRes(await jsx(`ft_tagSelection(${lit(tag.name)}, ${tag.color}, ${$("mk-marker").checked ? 1 : 0}, ${$("mk-name").checked ? 1 : 0}, ${lit(tagNames())})`), "Marcar").split(":");
        status(res[1] === "0" ? `Marcador "${tag.name}" no playhead` : `${res[1]} ${res[1] === "1" ? "bloco marcado" : "blocos marcados"} como "${tag.name}"`);
      });
    });
    box.appendChild(b);
  });
}
renderTags();

function addTag() {
  const name = $("mk-new").value.replace(/[|\[\]]/g, "").trim();
  if (!name) return;
  const tags = getTags();
  if (tags.some((t) => t.name.toLowerCase() === name.toLowerCase())) { status("Esse tipo já existe.", true); return; }
  // pega a cor menos usada, para os tipos novos não repetirem cor à toa
  const use = MARKER_COLORS.map((_, i) => tags.filter((t) => t.color === i).length);
  saveConfig({ tags: tags.concat({ name, color: use.indexOf(Math.min(...use)) }) });
  $("mk-new").value = "";
  renderTags();
}
$("mk-add").addEventListener("click", addTag);
$("mk-new").addEventListener("keydown", (e) => { if (e.key === "Enter") addTag(); });

$("mk-edit").addEventListener("click", () => {
  const on = $("mk-tags").classList.toggle("editing");
  $("mk-edit").textContent = on ? "Pronto (clique num tipo para remover)" : "Remover tipos da lista";
});

$("mk-clear").addEventListener("click", () => guard(null, async () => {
  const res = okRes(await jsx(`ft_untagSelection(${lit(tagNames())})`), "Marcar").split(":");
  status(`Marcação retirada de ${res[1]} clipes`);
}));

const clock = (t) => {
  const s = Math.round(t), p = (n) => String(n).padStart(2, "0");
  return `${p(Math.floor(s / 3600))}:${p(Math.floor(s / 60) % 60)}:${p(s % 60)}`;
};

$("mk-export").addEventListener("click", () => guard(null, async () => {
  const data = JSON.parse(await jsx(`ft_listTagged(${lit(tagNames())})`));
  if (data.err) throw new Error(data.err);
  if (!data.items.length) throw new Error("Essa sequência ainda não tem blocos marcados.");
  const items = data.items.sort((a, b) => a.start - b.start);
  const cell = (v) => '"' + String(v).replace(/"/g, '""') + '"';
  const rows = [["Início", "Fim", "Duração (s)", "Tipo", "Clipe"].map(cell).join(";")]
    .concat(items.map((m) => [clock(m.start), clock(m.end), (m.end - m.start).toFixed(1).replace(".", ","), m.name, m.clip].map(cell).join(";")));
  const dir = await outDir("Decupagem");
  const file = path.join(dir, `${safeName(data.name)}_decupagem_${stampNow()}.csv`);
  fs.writeFileSync(file, "﻿" + rows.join("\r\n"));
  status(`Lista salva: ${items.length} blocos em ${path.basename(file)}`);
}));
