// Pokan Tools — trilha na fala, zoom, barra com título, versões, conferência e narração
// Usa os utilitários de main.js e extras.js (run, jsx, guard, okRes, seqInfo, seqWav, measure, buildAss…)

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

// ---------- TRILHA NA FALA ----------

// Linhas do silencedetect -> trechos COM som, em segundos a partir do início do trecho analisado
function soundRanges(lines, dur) {
  const sil = [];
  let open = null;
  lines.forEach((l) => {
    const s = l.match(/silence_start: (-?[\d.]+)/), e = l.match(/silence_end: ([\d.]+)/);
    if (s) open = Math.max(0, parseFloat(s[1]));
    if (e && open != null) { sil.push([open, Math.min(dur, parseFloat(e[1]))]); open = null; }
  });
  if (open != null) sil.push([open, dur]);
  const out = [];
  let cur = 0;
  sil.forEach(([s, e]) => { if (s > cur) out.push([cur, s]); cur = Math.max(cur, e); });
  if (cur < dur) out.push([cur, dur]);
  return out;
}

// Junta falas separadas por pausas curtas e descarta estalos
function mergeRanges(ranges, gap, minLen) {
  const out = [];
  ranges.slice().sort((a, b) => a[0] - b[0]).forEach(([s, e]) => {
    const last = out[out.length - 1];
    if (last && s - last[1] < gap) last[1] = Math.max(last[1], e);
    else out.push([s, e]);
  });
  return out.filter(([s, e]) => e - s >= minLen);
}

const DUCK_HOLD = 0.15; // quanto a música espera depois da fala antes de subir

// Pontos de volume para um clipe de música [ms, me]: [tempo, 1 = normal | 0 = abaixado]
function duckPoints(speech, ms, me, fade) {
  const pts = [];
  const push = (t, f) => {
    t = clamp(t, ms, me);
    const last = pts[pts.length - 1];
    if (last && t <= last[0] + 0.01) { if (last[1] !== f && t >= me - 0.01) last[1] = f; return; }
    pts.push([t, f]);
  };
  const inside = speech.map(([s, e]) => [Math.max(s, ms), Math.min(e, me)]).filter(([s, e]) => e - s > 0.05);
  if (!inside.length) return pts;
  push(ms, inside[0][0] - fade <= ms + 0.02 ? 0 : 1);
  inside.forEach(([s, e]) => {
    if (s - fade > ms + 0.02) { push(s - fade, 1); push(s, 0); }
    if (e + DUCK_HOLD + fade >= me - 0.02) push(me, 0);
    else { push(e + DUCK_HOLD, 0); push(e + DUCK_HOLD + fade, 1); }
  });
  const last = pts[pts.length - 1];
  if (last[0] < me - 0.02) push(me, last[1]);
  return pts;
}

async function speechOf(c) {
  const dur = c.end - c.start;
  const thr = Math.round(clamp((await noiseFloor(c)) + 15, -50, -28));
  const lines = [];
  await run(BIN.ffmpeg, ["-hide_banner", "-nostats", "-ss", String(c.inPoint), "-t", String(dur), "-i", c.path, "-vn",
    "-af", `silencedetect=noise=${thr}dB:d=0.3`, "-f", "null", "-"], (l) => lines.push(l));
  return soundRanges(lines, dur).map(([s, e]) => [c.start + s, c.start + e]);
}

async function fillVoiceTracks() {
  try {
    const data = JSON.parse(await jsx("ft_audioTracks()"));
    if (data.err) return;
    const sel = $("du-track"), keep = sel.value;
    sel.innerHTML = "";
    data.tracks.forEach((t) => {
      const o = document.createElement("option");
      o.value = t.i;
      o.textContent = `A${t.i + 1} (${t.n} ${t.n === 1 ? "clipe" : "clipes"})`;
      sel.appendChild(o);
    });
    if (data.tracks.some((t) => String(t.i) === keep)) sel.value = keep;
  } catch (e) {}
}
document.querySelector('.segb[data-mode="duck"]').addEventListener("click", fillVoiceTracks);
$("du-fade").addEventListener("input", () => { $("du-fade-v").textContent = num($("du-fade").value, 2).replace(/0$/, "") + " s"; });

$("du-go").addEventListener("click", () => guard($("du-go"), async () => {
  const music = JSON.parse(await jsx("ft_selectedAudioClips()"));
  if (music.err) throw new Error("Selecione a música na timeline.");
  const voiceIdx = Number($("du-track").value), fade = Number($("du-fade").value), db = Number($("du-db").value);
  const voice = JSON.parse(await jsx(`ft_trackClips(${voiceIdx})`));
  if (voice.err) throw new Error(voice.err);
  const from = Math.min(...music.clips.map((c) => c.start)), to = Math.max(...music.clips.map((c) => c.end));
  const talk = voice.clips.filter((c) => c.end > from && c.start < to);
  if (!talk.length) throw new Error(`Não há clipes de voz na trilha A${voiceIdx + 1} em cima dessa música.`);
  let speech = [];
  for (let i = 0; i < talk.length; i++) {
    status(`Ouvindo a voz ${i + 1}/${talk.length}…`);
    progress((i / talk.length) * 90);
    speech = speech.concat(await speechOf(talk[i]));
  }
  speech = mergeRanges(speech, 2 * fade + DUCK_HOLD + 0.2, 0.15);
  let done = 0, keys = 0, skipped = 0;
  for (const c of music.clips) {
    const pts = duckPoints(speech, c.start, c.end, fade);
    if (pts.length < 2) continue;
    const res = okRes(await jsx(`ft_duck(${lit(c.nodeId)}, ${lit(pts.map(([t, f]) => t.toFixed(4) + ":" + f).join(";"))}, ${db}, ${voiceIdx})`), "Trilha na fala").split(":")[1];
    if (res === "SAME") throw new Error("A música selecionada está na mesma trilha da voz. Escolha a trilha certa da voz.");
    if (res === "KEY") { skipped++; continue; }
    done++;
    keys += Number(res);
  }
  if (!done && skipped) throw new Error("Essa música já tem keyframes de volume. Use o botão de tirar o ajuste e tente de novo.");
  if (!done) throw new Error("Não achei fala em cima dessa música.");
  status(`Pronto: música abaixa ${db} dB em ${speech.length} falas (${keys} pontos)` + (skipped ? `; ${skipped} clipes com keyframes ficaram de fora` : ""));
}));

$("du-undo").addEventListener("click", () => guard(null, async () => {
  const n = okRes(await jsx("ft_unduck()"), "Trilha na fala").split(":")[1];
  status(n === "0" ? "Nenhum clipe de áudio selecionado tinha ajuste." : `Ajuste retirado de ${n} ${n === "1" ? "clipe" : "clipes"}`);
}));

// ---------- ZOOM ----------

// Escala original de cada clipe que recebeu zoom, para poder desfazer depois
const zoomBases = () => loadConfig().zoom || {};
const zoomCsv = () => Object.entries(zoomBases()).map(([k, v]) => k + "=" + v).join("|");

$("zm-amt").addEventListener("input", () => { $("zm-amt-v").textContent = $("zm-amt").value + "%"; });

$("zm-go").addEventListener("click", () => guard($("zm-go"), async () => {
  const res = okRes(await jsx(`ft_zoom(${lit($("zm-style").value)}, ${Number($("zm-amt").value)}, ${lit(zoomCsv())})`), "Zoom").split(":");
  const map = zoomBases();
  (res[2] || "").split("|").filter(Boolean).forEach((kv) => { const [k, v] = kv.split("="); map[k] = Number(v); });
  const keys = Object.keys(map);
  keys.slice(0, Math.max(0, keys.length - 800)).forEach((k) => delete map[k]);
  saveConfig({ zoom: map });
  status(`Pronto: zoom de ${$("zm-amt").value}% em ${res[1]} ${res[1] === "1" ? "trecho" : "trechos"}`);
}));

$("zm-undo").addEventListener("click", () => guard(null, async () => {
  const res = okRes(await jsx(`ft_unzoom(${lit(zoomCsv())})`), "Zoom").split(":");
  status(`Zoom retirado de ${res[1]} ${res[1] === "1" ? "trecho" : "trechos"}` + (res[2] !== "0" ? `; ${res[2]} não tinham zoom do painel` : ""));
}));

// ---------- BARRA DE PROGRESSO E TÍTULO ----------

function barOpts() {
  return {
    bar: $("br-bar").checked, barpos: $("br-barpos").value, thick: Number($("br-thick").value), barcolor: $("br-barcolor").value,
    rail: $("br-rail").checked, title: $("br-title").checked, text: $("br-text").value.trim(), font: $("br-font").value,
    size: Number($("br-size").value), pos: Number($("br-pos").value), color: $("br-color").value, upper: $("br-upper").checked,
  };
}
function updateBarUi() {
  const o = barOpts();
  $("br-bar-opts").classList.toggle("hidden", !o.bar);
  $("br-title-opts").classList.toggle("hidden", !o.title);
  $("br-thick-v").textContent = num(o.thick, 1) + "%";
  $("br-size-v").textContent = num(o.size, 1) + "%";
  $("br-pos-v").textContent = o.pos + "% (" + (o.pos < 35 ? "em cima" : o.pos > 65 ? "embaixo" : "no meio") + ")";
}
(function initBar() {
  const s = loadConfig().bar || {};
  const set = (id, v, prop) => { if (v != null) $(id)[prop || "value"] = v; };
  set("br-bar", s.bar, "checked"); set("br-barpos", s.barpos); set("br-thick", s.thick); set("br-barcolor", s.barcolor);
  set("br-rail", s.rail, "checked"); set("br-title", s.title, "checked"); set("br-size", s.size); set("br-pos", s.pos);
  set("br-color", s.color); set("br-upper", s.upper, "checked");
  ["br-bar", "br-barpos", "br-thick", "br-barcolor", "br-rail", "br-title", "br-font", "br-size", "br-pos", "br-color", "br-upper"].forEach((id) => {
    $(id).addEventListener("input", () => { updateBarUi(); const o = barOpts(); delete o.text; saveConfig({ bar: o }); });
  });
  updateBarUi();
})();

// Monta o comando do ffmpeg: fundo transparente + trilho + título (ASS) + barra que cresce com o tempo
function barCommand(o, info, ass, out) {
  const W = info.width, H = info.height, D = info.dur.toFixed(3), fps = fpsArg(info.frame);
  const bh = Math.max(2, Math.round(H * o.thick / 100 / 2) * 2), y = o.barpos === "top" ? 0 : H - bh;
  const args = ["-y", "-f", "lavfi", "-i", `color=c=black@0.0:s=${W}x${H}:r=${fps}:d=${D},format=rgba`];
  const chain = [];
  if (o.bar && o.rail) chain.push(`drawbox=x=0:y=${y}:w=iw:h=${bh}:color=white@0.28:t=fill:replace=1`);
  if (ass) chain.push(`subtitles=${ass}:alpha=1`);
  let graph = `[0:v]${chain.length ? chain.join(",") : "null"}[b]`, last = "[b]";
  if (o.bar) {
    args.push("-f", "lavfi", "-i", `color=c=0x${CAP_COLORS[o.barcolor].css.slice(1)}:s=${W}x${bh}:r=${fps}:d=${D}`);
    graph += `;[b][1:v]overlay=x='-w+w*t/${D}':y=${y}:shortest=1:format=auto[o]`;
    last = "[o]";
  }
  return args.concat(["-filter_complex", graph, "-map", last, "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le", "-q:v", "20",
    "-progress", "pipe:1", "-nostats", out]);
}

$("br-go").addEventListener("click", () => guard($("br-go"), async () => {
  const o = barOpts();
  if (o.title && !o.text) throw new Error("Escreva o título ou desmarque a opção.");
  if (!o.bar && !o.title) throw new Error("Marque a barra, o título ou os dois.");
  const info = await seqInfo();
  if (!(info.dur > 0)) throw new Error("A sequência está vazia.");
  const dir = await outDir("Barra");
  const out = path.join(dir, `${safeName(info.name)}_barra_${stampNow()}.mov`);
  let ass = null;
  if (o.title) {
    ass = path.join(os.tmpdir(), `pt_tit_${Date.now()}.ass`);
    if (/[:',;\[\]\\ ]/.test(ass)) throw new Error("A pasta temporária tem caracteres que o ffmpeg não aceita.");
    const st = { font: o.font, size: o.size, pos: o.pos, color: o.color, outline: true, upper: o.upper };
    fs.writeFileSync(ass, buildAss([{ start: 0, end: info.dur, text: o.text }], st, info.width, info.height));
  }
  status("Desenhando…");
  await run(BIN.ffmpeg, barCommand(o, info, ass, out), (l) => {
    const m = l.match(/^out_time_ms=(\d+)/);
    if (m) { const pct = Math.min(100, (Number(m[1]) / 1e6 / info.dur) * 100); progress(pct); status(`Desenhando… ${Math.round(pct)}%`); }
  });
  if (ass) fs.unlink(ass, () => {});
  const res = okRes(await jsx(`ft_importTop(${lit(out)}, "Pokan Tools/Barra", 0, ${info.dur})`), "Barra");
  status(`Pronto: ${[o.bar && "barra", o.title && "título"].filter(Boolean).join(" e ")} na trilha ${res.replace("OK:", "")}`);
}));

// ---------- VERSÕES ----------

$("vs-go").addEventListener("click", () => guard($("vs-go"), async () => {
  const picks = Array.from(document.querySelectorAll(".vs-r:checked")).map((el) => el.value.split(":").map(Number));
  if (!picks.length) throw new Error("Marque pelo menos um formato.");
  const info = await seqInfo();
  const todo = picks.filter(([a, b]) => Math.abs(info.width / info.height - a / b) > 0.01);
  if (!todo.length) throw new Error("A sequência já está nesse formato. Marque outro.");
  const queue = $("vs-queue").checked;
  let preset = "", dir = "";
  if (queue) {
    preset = path.join(amePresets(), EXPORTS.alta.preset);
    if (!fs.existsSync(preset)) throw new Error("Preset não encontrado: " + path.basename(preset));
    dir = await outDir("Exports");
    status("Abrindo o Media Encoder…");
    okRes(await jsx("ft_launchAME()"), "Media Encoder");
  }
  let n = 0, queued = 0;
  for (const [a, b] of todo) {
    const name = `${info.name} ${a}x${b}`;
    status(`Reenquadrando para ${a}:${b}… (o Premiere analisa cada plano)`);
    progress((n / todo.length) * 100);
    const out = queue ? path.join(dir, `${safeName(info.name)}_${a}x${b}.mp4`) : "";
    const res = okRes(await jsx(`ft_reframe(${a}, ${b}, ${lit(name)}, ${lit($("vs-motion").value)}, ${lit(out)}, ${lit(preset)})`), "Versões").split(":");
    queued += Number(res[1]);
    n++;
  }
  if (queued && $("ex-start").checked) okRes(await jsx("ft_startBatch()"), "Fila");
  status(`Pronto: ${n} ${n === 1 ? "versão criada" : "versões criadas"} no projeto` + (queue ? `, ${queued} na fila do Media Encoder` : ""));
}));

// ---------- CONFERIR ANTES DE ENTREGAR ----------

function checkRow(kind, text, badge, at) {
  const el = document.createElement("div");
  el.className = "res " + kind + (at != null ? " go" : "");
  el.innerHTML = `<div class="grow"></div><b></b>`;
  el.firstChild.textContent = text;
  el.firstChild.title = text;
  el.lastChild.textContent = badge;
  if (at != null) el.addEventListener("click", () => jsx(`ft_goto(${at})`));
  $("ck-out").appendChild(el);
}

// Transforma o que foi medido em avisos: [tipo, texto, etiqueta, tempo]
function checkFindings(data, audio) {
  const rows = [];
  data.gaps.forEach(([s, e]) => rows.push(["bad", `Buraco sem imagem de ${num(e - s, 1)} s`, clock(s), s]));
  data.offline.forEach((c) => rows.push(["bad", `Mídia offline: ${c.name}`, clock(c.t), c.t]));
  data.tiny.forEach((c) => rows.push(["bad", `Clipe de 1 ou 2 quadros na V${c.track} (resto de corte?)`, clock(c.t), c.t]));
  if (audio) {
    if (!isFinite(audio.i)) rows.push(["bad", "A sequência está sem som", "áudio", null]);
    else {
      if (audio.tp > -1) rows.push(["bad", `Pico em ${signed(audio.tp)}: pode estourar (o limite é −1 dB)`, "áudio", null]);
      if (Math.abs(audio.i - (-14)) > 2) rows.push(["bad", `Volume em ${num(audio.i, 1)} LUFS: ${audio.i < -14 ? "baixo" : "alto"} para as redes (o alvo é −14)`, "áudio", null]);
      audio.silences.forEach(([s, e]) => rows.push(["bad", `Silêncio total de ${num(e - s, 1)} s`, clock(s), s]));
    }
  }
  return rows;
}

$("ck-go").addEventListener("click", () => guard($("ck-go"), async () => {
  $("ck-out").innerHTML = "";
  status("Conferindo a timeline…");
  progress(10);
  const data = JSON.parse(await jsx("ft_check()"));
  if (data.err) throw new Error(data.err);
  if (!data.clips) throw new Error("A sequência não tem clipes de vídeo.");
  let audio = null;
  if ($("ck-audio").checked) {
    const wav = await seqWav();
    status("Medindo o áudio…");
    progress(60);
    audio = await measure(wav);
    const lines = [];
    await run(BIN.ffmpeg, ["-hide_banner", "-nostats", "-i", wav, "-af", "silencedetect=noise=-60dB:d=2", "-f", "null", "-"], (l) => lines.push(l));
    const sound = soundRanges(lines, data.dur);
    audio.silences = [];
    let cur = 0;
    sound.forEach(([s, e]) => { if (s - cur >= 2) audio.silences.push([cur, s]); cur = e; });
    if (data.dur - cur >= 2) audio.silences.push([cur, data.dur]);
    fs.unlink(wav, () => {});
  }
  const rows = checkFindings(data, audio);
  rows.forEach((r) => checkRow(r[0], r[1], r[2], r[3]));
  checkRow("fine", `${data.clips} clipes de vídeo, ${clock(data.dur)} de duração`, "ok", null);
  if (audio && isFinite(audio.i)) checkRow("fine", `Volume ${num(audio.i, 1)} LUFS, pico ${signed(audio.tp)}`, "ok", null);
  status(rows.length ? `${rows.length} ${rows.length === 1 ? "ponto" : "pontos"} para olhar antes de entregar` : "Tudo certo: nenhum problema encontrado.");
}));

// ---------- NARRAÇÃO ----------

const NA_LANGS = ["pt_BR", "pt_PT", "en_US", "es_ES", "es_MX"];
let macVoices = null, elevenVoices = null;

function parseSayVoices(text) {
  return text.split("\n").map((l) => l.match(/^(.+?)\s+([a-z]{2}_[A-Z]{2})\s+#/)).filter((m) => m && NA_LANGS.includes(m[2]))
    .map((m) => ({ id: m[1].trim(), lang: m[2], name: m[1].trim().replace(/\s*\(.*$/, "") + " · " + m[2].replace("_", "-") }))
    .sort((a, b) => NA_LANGS.indexOf(a.lang) - NA_LANGS.indexOf(b.lang));
}

function elevenCall(key, method, apiPath, body, accept) {
  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: "api.elevenlabs.io", path: apiPath, method,
      headers: Object.assign({ "xi-api-key": key, Accept: accept }, body ? { "Content-Type": "application/json" } : {}),
    }, (res) => {
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () => {
        const buf = Buffer.concat(chunks);
        if (res.statusCode !== 200) {
          let msg = buf.toString();
          try { const j = JSON.parse(msg); msg = (j.detail && (j.detail.message || j.detail)) || msg; } catch (e) {}
          reject(new Error("ElevenLabs: " + String(msg).slice(0, 160)));
        } else resolve(buf);
      });
    });
    req.on("error", reject);
    req.end(body ? JSON.stringify(body) : undefined);
  });
}
const elevenKey = () => $("ai-key").value.trim() || loadConfig().elevenKey || "";

function fillVoices(list, saved) {
  const sel = $("na-voice");
  sel.innerHTML = "";
  list.forEach((v) => { const o = document.createElement("option"); o.value = v.id; o.textContent = v.name; sel.appendChild(o); });
  if (saved && list.some((v) => v.id === saved)) sel.value = saved;
}

async function loadVoices() {
  const mac = $("na-engine").value === "mac", cfg = loadConfig().voz || {};
  $("na-rate-f").classList.toggle("hidden", !mac);
  if (mac) {
    if (!macVoices) macVoices = parseSayVoices(await run("/usr/bin/say", ["-v", "?"]));
    fillVoices(macVoices, cfg.mac || "Luciana");
    return;
  }
  const key = elevenKey();
  if (!key) { fillVoices([], null); status("Cole a chave da ElevenLabs em SFX > IA para usar essas vozes.", true); return; }
  if (!elevenVoices) {
    status("Buscando as vozes…");
    const j = JSON.parse((await elevenCall(key, "GET", "/v1/voices", null, "application/json")).toString());
    elevenVoices = j.voices.map((v) => ({ id: v.voice_id, name: v.name }));
    status("Pronto.");
  }
  fillVoices(elevenVoices, cfg.eleven);
}
const rateLabel = (r) => (r < 165 ? "devagar" : r > 200 ? "rápida" : "normal");
$("na-engine").addEventListener("change", () => guard(null, async () => { saveConfig({ vozEngine: $("na-engine").value }); await loadVoices(); }));
$("na-rate").addEventListener("input", () => { $("na-rate-v").textContent = rateLabel(Number($("na-rate").value)); });
document.querySelector('.segb[data-mode="voz"]').addEventListener("click", () => { if (!$("na-voice").options.length) loadVoices().catch((e) => status(e.message, true)); });
if (loadConfig().vozEngine) $("na-engine").value = loadConfig().vozEngine;

$("na-go").addEventListener("click", () => guard($("na-go"), async () => {
  const text = $("na-text").value.trim(), voice = $("na-voice").value, mac = $("na-engine").value === "mac";
  if (!text) throw new Error("Escreva o texto da narração.");
  if (!voice) throw new Error("Escolha a voz.");
  const dir = await outDir("Narracao");
  const out = path.join(dir, `Narracao_${safeName(text).slice(0, 24).replace(/ /g, "_")}_${stampNow()}.wav`);
  const tmp = path.join(os.tmpdir(), `pt_voz_${Date.now()}`);
  status("Gerando a narração…");
  progress(30);
  const cfg = loadConfig().voz || {};
  let src;
  if (mac) {
    src = tmp + ".aiff";
    fs.writeFileSync(tmp + ".txt", text);
    await run("/usr/bin/say", ["-v", voice, "-r", $("na-rate").value, "-o", src, "-f", tmp + ".txt"]);
    fs.unlink(tmp + ".txt", () => {});
    cfg.mac = voice;
  } else {
    const key = elevenKey();
    if (!key) throw new Error("Cole a chave da ElevenLabs em SFX > IA.");
    src = tmp + ".mp3";
    fs.writeFileSync(src, await elevenCall(key, "POST", `/v1/text-to-speech/${encodeURIComponent(voice)}`, { text, model_id: "eleven_multilingual_v2" }, "audio/mpeg"));
    cfg.eleven = voice;
  }
  saveConfig({ voz: cfg });
  progress(75);
  await run(BIN.ffmpeg, ["-y", "-i", src, "-ac", "2", "-ar", "48000", "-c:a", "pcm_s24le", out]);
  fs.unlink(src, () => {});
  const res = await importToPremiere(out, "Pokan Tools/Narracao", $("sfx-place").checked ? "playhead" : "none", "audio");
  addResult(out);
  status(res === "OK:bin" ? "Pronto: narração no bin Pokan Tools/Narracao" : `Pronto: narração na trilha ${res.replace("OK:", "")}`);
}));
