// Pokan Tools — atualização pelo próprio painel
// O pacote fica no site da Pokan. Antes de instalar, o painel confere a assinatura do pacote com a
// chave pública abaixo; a chave privada só existe no Mac que publica (PokanTools/sign/update_key.pem).

const UPD_URL = "https://pokanfilmes.com.br/pokan-tools/";
const UPD_KEY = `-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAsRiXbuXFGC8hpreOMY0p
51irh7ZpOoqpPsJ66D+PeRLy+RvMHeRgl5+PspNrMKibyk3ds0T1ITJfWdTadKV1
qVT+7j12eMWFGzKkDVdRcXU6+fOOYnYkFBR9F5qxDL+FJ6CE3h1Va5jUVsXyTBqS
q5TZSBTTPMPvSBF+/VyPa+p2w6PDEQg0PtGsDFbGknU5RjLzpwnbo+bRjgVVDK8E
uLP/qTFJLFhCf7/+m+rxFhXUdSokkf7bIeYtBSKMSw1b1uvTH5QhHyE1NXxDrbWv
Zq05cgCKPBOO2b1v3nVfqjVQhWdihtt3FOAam+DXaySCzYHHGsGl9B6QkKyXUgX4
XcsAEKO5XxLxsWi8URq3hE46DwVZOfvKxc7w6vXZTu+GSR+EhLK9wzib6HNosfVK
D1kC9OngB0wU9xI1bouJe5Mdr6Np1dZ550764WiQvqEYlAn+4oLRxWGRULhUrm8W
ajkvx5w6xLsbtLn5j12p89NbEPIqcPnipcm8wfAHtb9jAgMBAAE=
-----END PUBLIC KEY-----`;
const VERSION_RE = /^\d{8}\.\d{4}$/; // ano, mês, dia, hora e minuto da publicação

function localVersion() {
  try { return fs.readFileSync(path.join(EXT_DIR, "versao.txt"), "utf8").trim(); } catch (e) { return "0"; }
}

function httpsGet(url, onProgress, hops) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && (hops || 0) < 3) {
        res.resume();
        return resolve(httpsGet(new URL(res.headers.location, url).toString(), onProgress, (hops || 0) + 1));
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error("O site respondeu " + res.statusCode + ".")); }
      const chunks = [], total = Number(res.headers["content-length"]) || 0;
      let got = 0;
      res.on("data", (c) => { chunks.push(c); got += c.length; if (onProgress && total) onProgress(got / total); });
      res.on("end", () => resolve(Buffer.concat(chunks)));
    });
    req.setTimeout(20000, () => req.destroy(new Error("O site demorou demais para responder.")));
    req.on("error", reject);
  });
}

// Informações da versão publicada, ou null se não houver nada mais novo que a instalada
async function newerVersion() {
  const info = JSON.parse((await httpsGet(UPD_URL + "versao.json?t=" + Date.now())).toString());
  if (!VERSION_RE.test(info.version) || !/^[\w.-]+\.zip$/.test(info.file)) throw new Error("Aviso de versão fora do formato.");
  return info.version > localVersion() ? info : null;
}

// Baixa o pacote e só devolve se o conteúdo for exatamente o que foi assinado na publicação
async function downloadUpdate(info, onProgress) {
  const buf = await httpsGet(UPD_URL + info.file, onProgress);
  const sha = crypto.createHash("sha256").update(buf).digest("hex");
  let signed = false;
  try { signed = crypto.verify("sha256", buf, UPD_KEY, Buffer.from(String(info.sig), "base64")); } catch (e) {}
  if (sha !== info.sha256 || !signed) throw new Error("A atualização não passou na conferência de segurança e não foi instalada. Avise o Luis.");
  return buf;
}

// Abre o pacote numa pasta temporária e roda o instalador que vem dentro dele
async function applyUpdate(buf, onStep) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "pt_upd_"));
  try {
    const zip = path.join(dir, "atualizacao.zip");
    fs.writeFileSync(zip, buf);
    await run("/usr/bin/unzip", ["-oq", zip, "-d", dir]);
    const script = path.join(dir, "Pokan Tools - Atualizacao", "instalar-pokan-tools.sh");
    if (!fs.existsSync(script)) throw new Error("O pacote de atualização veio incompleto.");
    let failed = null;
    try {
      await run("/bin/bash", [script], (l) => {
        if (l.indexOf("▸") === 0 && onStep) onStep(l.slice(1).trim());
        if (l.indexOf("✗") === 0) failed = l.slice(1).trim();
      });
    } catch (e) {
      throw new Error(failed || "A instalação da atualização falhou.");
    }
  } finally {
    cp.exec("rm -rf " + JSON.stringify(dir));
  }
}

let updInfo = null;

async function checkUpdate() {
  try {
    updInfo = await newerVersion();
    $("upd-btn").classList.toggle("hidden", !updInfo);
    if (updInfo) $("upd-btn").title = "Versão nova: " + updInfo.version + " (instalada: " + localVersion() + ")";
  } catch (e) {
    log("atualização: " + e.message);
  }
}

$("upd-btn").addEventListener("click", () => guard(null, async () => {
  if (!updInfo) return;
  const info = updInfo;
  status("Baixando a atualização…");
  progress(2);
  const buf = await downloadUpdate(info, (f) => progress(2 + f * 38));
  progress(45);
  await applyUpdate(buf, (step) => status("Atualizando: " + step + "…"));
  updInfo = null;
  $("upd-btn").classList.add("hidden");
  status("Atualizado. Feche o Premiere (Cmd+Q) e abra de novo para usar a versão nova.");
}));

$("open-dir").title = "Pokan Tools, versão " + localVersion();
setTimeout(checkUpdate, 3000);
setInterval(checkUpdate, 6 * 3600 * 1000);
