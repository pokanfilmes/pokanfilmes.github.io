// Pokan Tools — painel (CEP com Node habilitado)
const cp = require("child_process");
const fs = require("fs");
const path = require("path");
const os = require("os");
const https = require("https");

const TOOLS = path.join(os.homedir(), "Library/Application Support/PokanTools");
const BIN = {
  ffmpeg: path.join(TOOLS, "bin/ffmpeg"),
  ffprobe: path.join(TOOLS, "bin/ffprobe"),
  ytdlp: path.join(TOOLS, "bin/yt-dlp"),
  python: path.join(TOOLS, "venv/bin/python"),
  node: "/usr/local/bin/node",
};
const CONFIG = path.join(TOOLS, "config.json");

const $ = (id) => document.getElementById(id);
let lastDir = null;

// ---------- utilitários ----------

function loadConfig() {
  try { return JSON.parse(fs.readFileSync(CONFIG, "utf8")); } catch (e) { return {}; }
}
function saveConfig(patch) {
  const c = Object.assign(loadConfig(), patch);
  fs.writeFileSync(CONFIG, JSON.stringify(c, null, 2));
}

// Registro em arquivo: é por ele que dá para ver de fora o que deu errado dentro do Premiere
const LOG = path.join(TOOLS, "painel.log");
function log(msg) {
  try { fs.appendFileSync(LOG, new Date().toISOString() + " " + msg + "\n"); } catch (e) {}
}

function status(msg, isErr) {
  $("status").textContent = msg;
  $("status").classList.toggle("err", !!isErr);
  $("status").title = msg;
  if (isErr) log("ERRO " + msg);
}
function progress(pct) {
  if (pct == null) { $("bar").classList.add("hidden"); return; }
  $("bar").classList.remove("hidden");
  $("bar-fill").style.width = Math.max(0, Math.min(100, pct)) + "%";
}

function jsx(code) {
  return new Promise((res) => window.__adobe_cep__.evalScript(code, res));
}
const lit = (s) => JSON.stringify(String(s));

function run(cmd, args, onLine) {
  return new Promise((resolve, reject) => {
    const p = cp.spawn(cmd, args, { env: Object.assign({}, process.env, { PYTHONUNBUFFERED: "1" }) });
    let out = "", err = "";
    const feed = (chunk, isErr) => {
      const s = chunk.toString();
      if (isErr) err += s; else out += s;
      if (onLine) s.split(/[\r\n]+/).forEach((l) => l.trim() && onLine(l.trim()));
    };
    p.stdout.on("data", (c) => feed(c, false));
    p.stderr.on("data", (c) => feed(c, true));
    p.on("error", reject);
    p.on("close", (code) => {
      if (code === 0) resolve(out);
      else reject(new Error((err || out).trim().split("\n").slice(-3).join(" ") || "falhou (código " + code + ")"));
    });
  });
}

async function probeDuration(file) {
  const out = await run(BIN.ffprobe, ["-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", file]);
  return parseFloat(out) || 0;
}

async function outDir(sub) {
  const proj = await jsx("ft_projectDir()");
  const base = proj && proj !== "EvalScript error." ? path.join(proj, "Pokan Tools") : path.join(os.homedir(), "Movies/Pokan Tools");
  const dir = path.join(base, sub);
  fs.mkdirSync(dir, { recursive: true });
  lastDir = dir;
  return dir;
}

async function importToPremiere(file, bin, where, kind, skip) {
  const dur = await probeDuration(file).catch(() => 5);
  const res = await jsx(`ft_import(${lit(file)}, ${lit(bin)}, ${lit(where)}, ${dur}, ${lit(kind)}, ${skip || 0})`);
  if (!res || res.indexOf("ERR") === 0) throw new Error("Premiere: " + res);
  return res;
}

function safeName(s) {
  return String(s).replace(/[\/\\:*?"<>|]/g, "").replace(/\s+/g, " ").trim().slice(0, 60) || "audio";
}

function pickFile(title, types) {
  const r = window.cep.fs.showOpenDialog(false, false, title, "", types);
  if (!r || !r.data || !r.data[0]) return null;
  // o Premiere devolve "file:///…%20…"; o ffmpeg precisa do caminho normal
  return /^file:\/\//.test(r.data[0]) ? decodeURIComponent(r.data[0].replace(/^file:\/\//, "")) : r.data[0];
}

async function selectedClip() {
  const raw = await jsx("ft_selectedClip()");
  let info;
  try { info = JSON.parse(raw); } catch (e) { throw new Error("Resposta do Premiere: " + raw); }
  if (info.err) throw new Error(info.err);
  return info;
}

function busy(btn, on) {
  document.querySelectorAll("button.primary").forEach((b) => { if (on) b.dataset.was = b.disabled; b.disabled = on ? true : b.dataset.was === "true"; });
  if (!on) progress(null);
}

async function guard(btn, fn) {
  busy(btn, true);
  try { await fn(); log("ok " + $("status").textContent); } catch (e) { status(e.message, true); console.error(e); }
  busy(btn, false);
}

// ---------- abas ----------

document.querySelectorAll(".tab").forEach((t) => t.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach((x) => x.classList.toggle("on", x === t));
  document.querySelectorAll(".pane").forEach((p) => p.classList.toggle("on", p.id === t.dataset.tab));
}));
document.querySelectorAll(".segb").forEach((b) => b.addEventListener("click", () => {
  const pane = b.closest(".pane");
  pane.querySelectorAll(".segb").forEach((x) => x.classList.toggle("on", x === b));
  pane.querySelectorAll(".mode").forEach((m) => m.classList.toggle("on", m.id === "m-" + b.dataset.mode));
}));
$("open-dir").addEventListener("click", () => {
  const d = lastDir || path.join(os.homedir(), "Movies/Pokan Tools");
  fs.mkdirSync(d, { recursive: true });
  cp.exec(`open ${JSON.stringify(d)}`);
});

// ---------- YOUTUBE ----------

const yt = { info: null, choice: null };
// O yt-dlp precisa de um motor de JavaScript para o YouTube: usa o deno que o instalador põe
// na pasta de ferramentas e, na falta dele, o node do sistema.
function jsRuntime() {
  const deno = path.join(TOOLS, "bin/deno");
  if (fs.existsSync(deno)) return ["--js-runtimes", "deno:" + deno];
  if (fs.existsSync(BIN.node)) return ["--js-runtimes", "node:" + BIN.node];
  return [];
}
const YT_JS = [...jsRuntime(), "--ffmpeg-location", path.dirname(BIN.ffmpeg), "--no-playlist"];

function fmtSize(bytes) {
  if (!bytes) return "";
  return bytes > 1e9 ? (bytes / 1e9).toFixed(1) + " GB" : Math.round(bytes / 1e6) + " MB";
}
function fmtTime(s) {
  s = Math.round(s || 0);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = String(s % 60).padStart(2, "0");
  return h ? `${h}:${String(m).padStart(2, "0")}:${ss}` : `${m}:${ss}`;
}

function buildChoices(info) {
  const formats = info.formats || [];
  const audio = formats.filter((f) => f.vcodec === "none" && f.acodec && f.acodec !== "none");
  const bestAudio = audio.sort((a, b) => (b.abr || 0) - (a.abr || 0))[0];
  const byHeight = {};
  // YouTube entrega vídeo e áudio separados; Instagram e TikTok entregam juntos (muxed).
  // Prefere H.264, vídeo puro quando há áudio separado, e download direto em vez de m3u8.
  formats.filter((f) => f.vcodec !== "none" && f.height && f.protocol !== "mhtml").forEach((f) => {
    const h = f.height;
    const isAvc = /^(avc|h264)/.test(f.vcodec || "");
    const muxed = !!f.acodec && f.acodec !== "none";
    if (!muxed && !bestAudio) return;
    const cur = byHeight[h];
    const score = (isAvc ? 1e8 : 0) + (muxed ? 0 : 1e7) + (f.protocol === "https" ? 1e6 : 0) + (f.fps || 0) * 1e3 + (f.tbr || 0);
    if (!cur || score > cur.score) byHeight[h] = { f, score, isAvc, muxed };
  });
  const choices = Object.keys(byHeight).map(Number).sort((a, b) => b - a).map((h) => {
    const { f, isAvc, muxed } = byHeight[h];
    const size = (f.filesize || f.filesize_approx || 0) + (!muxed && bestAudio ? bestAudio.filesize || bestAudio.filesize_approx || 0 : 0);
    const v = f.vcodec || "";
    const codec = isAvc ? "H.264" : /^vp0?9/.test(v) ? "VP9" : /^av01/.test(v) ? "AV1" : /^(hev|hvc|h265|bytevc1)/.test(v) ? "H.265" : "";
    return { kind: "video", spec: muxed ? f.format_id : `${f.format_id}+bestaudio[ext=m4a]/${f.format_id}+bestaudio`, isAvc,
      label: `${Math.min(f.width || h, h)}p${f.fps > 30 ? Math.round(f.fps) : ""}`, sub: [codec, fmtSize(size)].filter(Boolean).join(" · ") };
  });
  if (!choices.length) choices.push({ kind: "video", spec: "bv*+ba/b", isAvc: false, label: "Melhor disponível", sub: "" });
  choices.push({ kind: "audio", fmt: "wav", label: "Só áudio", sub: "WAV" });
  choices.push({ kind: "audio", fmt: "mp3", label: "Só áudio", sub: "MP3 320" });
  return choices;
}

function renderChoices(choices) {
  const box = $("yt-formats");
  box.innerHTML = "";
  choices.forEach((c, i) => {
    const el = document.createElement("div");
    el.className = "opt" + (i === 0 ? " on" : "");
    el.innerHTML = `<div class="grow"><b>${c.label}</b> <small>${c.sub}</small></div>`;
    el.addEventListener("click", () => {
      box.querySelectorAll(".opt").forEach((o) => o.classList.remove("on"));
      el.classList.add("on");
      yt.choice = c;
    });
    box.appendChild(el);
  });
  yt.choice = choices[0];
}

$("yt-url").addEventListener("keydown", (e) => { if (e.key === "Enter") $("yt-fetch").click(); });
$("yt-fetch").addEventListener("click", () => guard($("yt-fetch"), async () => {
  const url = $("yt-url").value.trim();
  if (!url) throw new Error("Cole um link primeiro.");
  status("Buscando qualidades…");
  progress(15);
  const out = await run(BIN.ytdlp, ["-J", ...YT_JS, url]).catch((e) => {
    if (/login|log in|cookies|private|rate-limit/i.test(e.message)) throw new Error("Esse link pede login (post privado ou bloqueio do site).");
    throw e;
  });
  let info = JSON.parse(out);
  if (info.entries && info.entries.length) info = info.entries[0]; // carrossel: pega o primeiro vídeo
  yt.info = info;
  $("yt-thumb").src = info.thumbnail || "";
  $("yt-title").textContent = info.title;
  $("yt-meta").textContent = [info.uploader, fmtTime(info.duration)].filter(Boolean).join(" · ");
  $("yt-info").classList.remove("hidden");
  renderChoices(buildChoices(info));
  $("yt-opts").classList.remove("hidden");
  status("Escolha a qualidade.");
}));

$("yt-go").addEventListener("click", () => guard($("yt-go"), async () => {
  const c = yt.choice, info = yt.info;
  if (!c || !info) throw new Error("Busque um link primeiro.");
  const dir = await outDir("Baixados");
  const base = safeName(info.title || info.id || "video");
  const args = [...YT_JS, "--newline", "--progress", "--print", "after_move:filepath",
    "--progress-template", "download:FT %(progress._percent_str)s %(progress._speed_str)s %(progress._eta_str)s"];
  if (c.kind === "audio") {
    args.push("-f", "bestaudio", "-x", "--audio-format", c.fmt, "--audio-quality", "0", "-o", path.join(dir, `${base}.%(ext)s`));
  } else {
    const tag = c.label;
    args.push("-f", c.spec, "--merge-output-format", c.isAvc ? "mp4" : "mkv",
      "-o", path.join(dir, `${base} [${tag}].%(ext)s`));
  }
  args.push(info.webpage_url || $("yt-url").value.trim());

  let file = null;
  status("Baixando…");
  await run(BIN.ytdlp, args, (l) => {
    const m = l.match(/^FT\s+([\d.]+)%\s*(\S*)\s*(\S*)/);
    if (m) {
      progress(parseFloat(m[1]));
      status(`Baixando ${m[1]}% · ${m[2]} · faltam ${m[3]}`);
    } else if (l.startsWith("/")) file = l;
  });
  if (!file || !fs.existsSync(file)) throw new Error("Download terminou mas não achei o arquivo.");

  if (c.kind === "video") {
    // confere o codec de verdade: Instagram e TikTok nem sempre informam antes do download
    const vcodec = (await run(BIN.ffprobe, ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_name", "-of", "default=nw=1:nk=1", file])).trim();
    // H.264 e H.265 o Premiere abre direto; VP9 e AV1 não
    if (vcodec !== "h264" && vcodec !== "hevc" && $("yt-h264").checked) {
      const total = info.duration || (await probeDuration(file));
      let mp4 = file.replace(/\.[^.]+$/, ".mp4");
      if (mp4 === file) mp4 = file.replace(/\.mp4$/, " H264.mp4");
      status("Convertendo para H.264… (demora alguns minutos)");
      await run(BIN.ffmpeg, ["-y", "-i", file, "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "320k", "-movflags", "+faststart", "-progress", "pipe:1", "-nostats", mp4], (l) => {
        const m = l.match(/^out_time_ms=(\d+)/);
        if (m && total) { const pct = (Number(m[1]) / 1e6 / total) * 100; progress(pct); status(`Convertendo para H.264… ${Math.round(pct)}%`); }
      });
      fs.unlinkSync(file);
      file = mp4;
    }
  }

  status("Importando no Premiere…");
  const where = $("yt-place").checked ? "playhead" : "none";
  const res = await importToPremiere(file, "Pokan Tools/Baixados", where, c.kind === "video" ? "video" : "audio");
  status(`Pronto: ${path.basename(file)} (${res.replace("OK:", "")})`);
}));

// ---------- SEPARAR ----------

const sep = { src: null };
const STEM_NAMES = { vocals: "Voz", no_vocals: "Fundo", drums: "Bateria", bass: "Baixo", other: "Outros" };

function setSepSource(src) {
  sep.src = src;
  $("sep-src").classList.remove("muted");
  $("sep-src").textContent = src.clip
    ? `${src.name} — trecho de ${fmtTime(src.end - src.start)} na timeline`
    : path.basename(src.path);
  $("sep-go").disabled = false;
}

$("sep-sel").addEventListener("click", () => guard(null, async () => {
  const c = await selectedClip();
  setSepSource({ path: c.path, name: c.name, clip: true, start: c.start, end: c.end, inPoint: c.inPoint, nodeId: c.nodeId });
  status("Clipe pronto para separar.");
}));
$("sep-file").addEventListener("click", () => {
  const f = pickFile("Escolha o áudio ou vídeo", ["mp4", "mov", "m4v", "mxf", "mkv", "webm", "avi", "mts", "wav", "mp3", "aif", "aiff", "m4a", "aac", "flac", "ogg"]);
  if (f) setSepSource({ path: f, name: path.basename(f), clip: false });
});

$("sep-go").addEventListener("click", () => guard($("sep-go"), async () => {
  const s = sep.src;
  if (!fs.existsSync(BIN.python)) throw new Error("O motor de separação ainda não foi instalado.");
  const dir = await outDir("Stems");
  const stamp = new Date().toISOString().slice(11, 19).replace(/:/g, "");
  const name = safeName(path.basename(s.name, path.extname(s.name))) + "_" + stamp;
  const wav = path.join(os.tmpdir(), `ft_${name}.wav`);

  status("Extraindo o áudio…");
  progress(2);
  const cut = s.clip ? ["-ss", String(s.inPoint), "-t", String(s.end - s.start)] : [];
  await run(BIN.ffmpeg, ["-y", ...cut, "-i", s.path, "-vn", "-ac", "2", "-ar", "44100", wav]);

  const mode = $("sep-mode").value, model = $("sep-model").value;
  const models = path.join(TOOLS, "models");
  const weights = path.join(models, model + ".safetensors"), config = path.join(models, model + "_config.json");
  if (!fs.existsSync(weights)) throw new Error("O modelo de separação não está instalado.");
  const finalDir = path.join(dir, name);

  status("Separando… (uns 3 s de espera para cada 1 s de áudio)");
  await run(BIN.python, [pyScript("separar.py"), wav, finalDir, weights, config, mode], (l) => {
    const m = l.match(/(\d+)%\|/);
    if (m) { progress(Number(m[1])); status(`Separando… ${m[1]}%`); }
  });
  fs.unlink(wav, () => {});

  const order = mode === "2" ? ["vocals", "no_vocals"] : ["vocals", "drums", "bass", "other"];
  const files = order.map((stem) => {
    const to = path.join(finalDir, `${STEM_NAMES[stem]}.wav`);
    fs.renameSync(path.join(finalDir, stem + ".wav"), to);
    return to;
  });

  status("Importando as trilhas…");
  const where = s.clip ? String(s.start) : "playhead";
  for (let i = 0; i < files.length; i++) {
    await importToPremiere(files[i], "Pokan Tools/Stems/" + name, where, "audio", 0);
  }
  if (s.clip && $("sep-mute").checked) await jsx(`ft_disableClip(${lit(s.nodeId)})`);
  status(`Pronto: ${files.length} trilhas em ${name}`);
}));

// ---------- SFX ----------

const vary = { src: null };

$("sy-dur").addEventListener("input", () => { $("sy-dur-v").textContent = Number($("sy-dur").value).toFixed(1).replace(".", ",") + " s"; });
$("ai-dur").addEventListener("input", () => {
  const v = Number($("ai-dur").value);
  $("ai-dur-v").textContent = v ? v.toFixed(1).replace(".", ",") + " s" : "automática";
});
$("ai-key").value = loadConfig().elevenKey || "";
$("ai-key").addEventListener("change", () => saveConfig({ elevenKey: $("ai-key").value.trim() }));

function addResult(file) {
  const el = document.createElement("div");
  el.className = "opt";
  el.innerHTML = `<button class="play">▶</button><div class="grow">${path.basename(file)}</div><button class="put">Timeline</button>`;
  const audio = new Audio("file://" + encodeURI(file));
  el.querySelector(".play").addEventListener("click", () => {
    audio.currentTime = 0;
    audio.play();
  });
  el.querySelector(".put").addEventListener("click", () => guard(null, async () => {
    const r = await importToPremiere(file, "Pokan Tools/SFX", "playhead", "audio");
    status(`Na timeline (${r.replace("OK:", "")})`);
  }));
  $("sfx-results").prepend(el);
}

async function finishSfx(files) {
  for (let i = 0; i < files.length; i++) {
    const where = i === 0 && $("sfx-place").checked ? "playhead" : "none";
    await importToPremiere(files[i], "Pokan Tools/SFX", where, "audio");
  }
  files.slice().reverse().forEach(addResult);
  status(`Pronto: ${files.length} sons no bin Pokan Tools/SFX`);
}

const TYPE_LABEL = { whoosh: "Whoosh", impact: "Impacto", riser: "Riser", reverse: "Reverso", subdrop: "SubDrop", pop: "Pop", glitch: "Glitch", ding: "Ding" };

$("sy-go").addEventListener("click", () => guard($("sy-go"), async () => {
  const type = $("sy-type").value, dur = Number($("sy-dur").value), n = Math.max(1, Math.min(12, Number($("sy-n").value) || 1));
  const dir = await outDir("SFX");
  const stamp = Date.now().toString(36).slice(-4);
  const files = [];
  for (let i = 0; i < n; i++) {
    status(`Sintetizando ${i + 1}/${n}…`);
    progress(((i + 1) / n) * 100);
    await new Promise((r) => setTimeout(r, 0));
    const seed = Math.floor(Math.random() * 1e9);
    const file = path.join(dir, `${TYPE_LABEL[type]}_${stamp}_${String(i + 1).padStart(2, "0")}.wav`);
    fs.writeFileSync(file, Buffer.from(FTSynth.render(type, dur, seed)));
    files.push(file);
  }
  await finishSfx(files);
}));

// Variações: cadeias de filtros do ffmpeg com parâmetros sorteados
function variationChain(intensity) {
  const k = [0, 0.35, 0.7, 1.1][intensity];
  const rnd = (a, b) => a + Math.random() * (b - a);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const f = ["aresample=48000"]; // asetrate abaixo assume 48 kHz na entrada
  const ratio = Math.pow(2, rnd(-7, 7) * k / 12); // até ±7 semitons no forte
  if (Math.random() < 0.5) f.push(`asetrate=48000*${ratio.toFixed(4)},aresample=48000,atempo=${(1 / ratio).toFixed(4)}`);
  else f.push(`asetrate=48000*${ratio.toFixed(4)},aresample=48000`);
  const extras = [
    () => `lowpass=f=${Math.round(rnd(1500, 9000) / (1 + k))}`,
    () => `highpass=f=${Math.round(rnd(150, 900) * k)}`,
    () => `aecho=0.8:0.6:${Math.round(rnd(40, 120))}|${Math.round(rnd(130, 300))}:${rnd(0.2, 0.45 * k + 0.1).toFixed(2)}|${rnd(0.1, 0.3 * k + 0.05).toFixed(2)}`,
    () => `vibrato=f=${rnd(4, 9).toFixed(1)}:d=${(0.15 * k).toFixed(2)}`,
    () => `chorus=0.6:0.8:${Math.round(rnd(25, 55))}:0.4:0.25:2`,
    () => `acrusher=bits=${Math.round(16 - 9 * k)}:mix=${(0.4 * k).toFixed(2)}`,
    () => "areverse",
  ];
  const count = intensity === 1 ? 1 : intensity === 2 ? 2 : 3;
  const used = new Set();
  while (used.size < count) used.add(pick(extras.slice(0, intensity === 1 ? 4 : extras.length)));
  used.forEach((fn) => f.push(fn()));
  f.push("alimiter=limit=0.89:level=false");
  return f.join(",");
}

function setVarySource(src) {
  vary.src = src;
  $("va-src").classList.remove("muted");
  $("va-src").textContent = src.clip ? `${src.name} (trecho da timeline)` : path.basename(src.path);
  $("va-go").disabled = false;
}
$("va-sel").addEventListener("click", () => guard(null, async () => {
  const c = await selectedClip();
  setVarySource({ path: c.path, name: c.name, clip: true, inPoint: c.inPoint, dur: c.end - c.start });
}));
$("va-file").addEventListener("click", () => {
  const f = pickFile("Escolha o som", ["wav", "mp3", "aif", "aiff", "m4a", "aac", "flac", "ogg", "mp4", "mov", "m4v", "mkv", "webm"]);
  if (f) setVarySource({ path: f, name: path.basename(f), clip: false });
});

$("va-go").addEventListener("click", () => guard($("va-go"), async () => {
  const s = vary.src, n = Math.max(1, Math.min(12, Number($("va-n").value) || 1)), intensity = Number($("va-int").value);
  const dir = await outDir("SFX");
  const base = safeName(path.basename(s.name, path.extname(s.name)));
  const stamp = Date.now().toString(36).slice(-4);
  const cut = s.clip ? ["-ss", String(s.inPoint), "-t", String(s.dur)] : [];
  const files = [];
  for (let i = 0; i < n; i++) {
    status(`Criando variação ${i + 1}/${n}…`);
    progress(((i + 1) / n) * 100);
    const file = path.join(dir, `${base}_var${stamp}_${String(i + 1).padStart(2, "0")}.wav`);
    await run(BIN.ffmpeg, ["-y", ...cut, "-i", s.path, "-vn", "-ar", "48000", "-ac", "2", "-af", variationChain(intensity), "-c:a", "pcm_s24le", file]);
    files.push(file);
  }
  await finishSfx(files);
}));

function elevenSfx(key, text, dur) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(Object.assign({ text, prompt_influence: 0.35 }, dur ? { duration_seconds: dur } : {}));
    const req = https.request({
      hostname: "api.elevenlabs.io", path: "/v1/sound-generation", method: "POST",
      headers: { "xi-api-key": key, "Content-Type": "application/json", Accept: "audio/mpeg" },
    }, (res) => {
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () => {
        const buf = Buffer.concat(chunks);
        if (res.statusCode !== 200) {
          let msg = buf.toString();
          try { const j = JSON.parse(msg); msg = (j.detail && (j.detail.message || j.detail)) || msg; } catch (e) {}
          reject(new Error("ElevenLabs: " + String(msg).slice(0, 160)));
        } else resolve(buf);
      });
    });
    req.on("error", reject);
    req.end(body);
  });
}

$("ai-go").addEventListener("click", () => guard($("ai-go"), async () => {
  const key = $("ai-key").value.trim(), text = $("ai-prompt").value.trim();
  if (!key) throw new Error("Cole a chave da ElevenLabs.");
  if (!text) throw new Error("Descreva o som.");
  saveConfig({ elevenKey: key });
  const n = Math.max(1, Math.min(6, Number($("ai-n").value) || 1)), dur = Number($("ai-dur").value) || null;
  const dir = await outDir("SFX");
  const base = safeName(text).slice(0, 30).replace(/ /g, "_");
  const stamp = Date.now().toString(36).slice(-4);
  let done = 0;
  status(`Gerando ${n} com IA…`);
  progress(5);
  const files = await Promise.all(Array.from({ length: n }, async (_, i) => {
    const buf = await elevenSfx(key, text, dur);
    const file = path.join(dir, `IA_${base}_${stamp}_${String(i + 1).padStart(2, "0")}.mp3`);
    fs.writeFileSync(file, buf);
    done++;
    progress((done / n) * 100);
    return file;
  }));
  await finishSfx(files);
}));

// ---------- início ----------

(function checkTools() {
  const missing = ["ffmpeg", "ytdlp", "python"].filter((k) => !fs.existsSync(BIN[k]));
  if (missing.length) status("Faltando: " + missing.join(", ") + " — rode o instalador.", true);
})();
